import { createClient } from '@supabase/supabase-js';

// Setup Supabase credentials with robust, tested fallbacks
const supabaseUrl = (import.meta as any).env?.VITE_SUPABASE_URL || "https://vtyfduzrysbjrnoeqojk.supabase.co";
const supabaseKey = (import.meta as any).env?.VITE_SUPABASE_ANON_KEY || "sb_publishable_KvRUiqDZCInRq_JXXPcIgA_o99t7Qf3";

export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  }
});

export const db = supabase;
export const auth = supabase.auth;

export type FirebaseUser = {
  uid: string;
  email: string | null;
};

// ----------------------------------------------------
// Error Handling
// ----------------------------------------------------
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  let errorMsg = '';
  if (error instanceof Error) {
    errorMsg = error.message;
  } else if (typeof error === 'object' && error !== null) {
    try {
      errorMsg = (error as any).message || (error as any).details || JSON.stringify(error);
    } catch {
      errorMsg = String(error);
    }
  } else {
    errorMsg = String(error);
  }

  const errInfo = {
    error: errorMsg,
    operationType,
    path
  };
  console.error('Supabase/Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// ----------------------------------------------------
// Case conversion helpers for snake_case DB mapping
// ----------------------------------------------------
const camelToSnake = (str: string): string => {
  return str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
};

const snakeToCamel = (str: string): string => {
  return str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());
};

export const toSnakeCase = (obj: any): any => {
  if (obj === null || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(toSnakeCase);
  
  const result: any = {};
  for (const key of Object.keys(obj)) {
    if (key === 'games' || key === 'response' || key === 'replies') {
      result[camelToSnake(key)] = obj[key];
    } else {
      result[camelToSnake(key)] = toSnakeCase(obj[key]);
    }
  }
  return result;
};

export const toCamelCase = (obj: any): any => {
  if (obj === null || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(toCamelCase);
  
  const result: any = {};
  for (const key of Object.keys(obj)) {
    if (key === 'games' || key === 'response' || key === 'replies') {
      result[snakeToCamel(key)] = obj[key];
    } else {
      result[snakeToCamel(key)] = toCamelCase(obj[key]);
    }
  }
  return result;
};

// Map Firestore collection names to Supabase tables
const mapCollectionName = (name: string): string => {
  if (name === 'settings') return 'system_settings';
  if (name === 'completions') return 'task_completions';
  if (name === 'videos') return 'video_tasks';
  return name;
};

// ----------------------------------------------------
// Reference Models
// ----------------------------------------------------
export interface DocRef {
  type: 'doc';
  collection: string;
  id: string;
  path: string;
}

export interface CollectionRef {
  type: 'collection';
  collection: string;
  path: string;
}

export interface QueryRef {
  type: 'query';
  collection: string;
  constraints: any[];
}

export const doc = (dbObj: any, collectionName: string, id?: string): DocRef => {
  const mappedCollection = mapCollectionName(collectionName);
  const finalId = id || 'gen-' + Math.random().toString(36).substring(2, 10);
  return {
    type: 'doc',
    collection: mappedCollection,
    id: finalId,
    path: `${mappedCollection}/${finalId}`
  };
};

export const collection = (dbObj: any, name: string): CollectionRef => {
  const mappedCollection = mapCollectionName(name);
  return {
    type: 'collection',
    collection: mappedCollection,
    path: mappedCollection
  };
};

export const query = (ref: any, ...constraints: any[]): QueryRef => {
  const baseCollection = ref.collection || ref.path;
  return {
    type: 'query',
    collection: baseCollection,
    constraints: constraints.filter(Boolean)
  };
};

// ----------------------------------------------------
// Constraints
// ----------------------------------------------------
export const where = (field: string, op: string, value: any) => {
  return { type: 'where', field, op, value };
};

export const orderBy = (field: string, direction: 'asc' | 'desc' = 'asc') => {
  return { type: 'orderBy', field, direction };
};

export const limit = (count: number) => {
  return { type: 'limit', count };
};

export const increment = (value: number) => {
  return { type: 'increment', value };
};

// ----------------------------------------------------
// Resolve increments inside data payloads
// ----------------------------------------------------
const resolveIncrements = async (collectionName: string, id: string, data: any) => {
  let hasIncrement = false;
  for (const key of Object.keys(data)) {
    if (data[key] && typeof data[key] === 'object' && data[key].type === 'increment') {
      hasIncrement = true;
      break;
    }
  }
  
  if (!hasIncrement) return data;
  
  const pkField = collectionName === 'users' ? 'uid' : 'id';
  const { data: existingRow, error } = await supabase
    .from(collectionName)
    .select('*')
    .eq(pkField, id)
    .maybeSingle();
    
  if (error) {
    console.error("Error fetching existing row for increment:", error);
  }
  
  const resolvedData = { ...data };
  for (const key of Object.keys(resolvedData)) {
    const val = resolvedData[key];
    if (val && typeof val === 'object' && val.type === 'increment') {
      const currentVal = existingRow ? Number(existingRow[key] || 0) : 0;
      resolvedData[key] = currentVal + val.value;
    }
  }
  
  return resolvedData;
};

// ----------------------------------------------------
// DB Operations
// ----------------------------------------------------
// ----------------------------------------------------
// Local Storage Fallback Engine
// ----------------------------------------------------
export const fallbackTables = new Set<string>();

const getLocalStorageKey = (table: string) => `sapc_fallback_${table}`;

const getLocalStorageTable = (table: string): any[] => {
  try {
    const raw = localStorage.getItem(getLocalStorageKey(table));
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error("LocalStorage read error:", e);
  }
  
  // Seed initial data if table is empty
  if (table === 'system_settings') {
    return [{
      id: 'global',
      provider_name: "SAPC STORE",
      m_pesa_number: "0755123456",
      airtel_number: "0688123456",
      tigo_number: "0711123456",
      halo_number: "0622123456",
      daily_withdraw_limit: 50000
    }];
  }
  return [];
};

const saveLocalStorageTable = (table: string, data: any[]) => {
  try {
    localStorage.setItem(getLocalStorageKey(table), JSON.stringify(data));
    window.dispatchEvent(new Event('storage'));
  } catch (e) {
    console.error("LocalStorage write error:", e);
  }
};

const isTableNotFound = (error: any): boolean => {
  if (!error) return false;
  const msg = typeof error === 'object' ? error.message || JSON.stringify(error) : String(error);
  return (
    msg.includes('PGRST205') ||
    msg.toLowerCase().includes('could not find the table') ||
    msg.toLowerCase().includes('schema cache') ||
    msg.toLowerCase().includes('relation') ||
    msg.toLowerCase().includes('does not exist')
  );
};

const fallbackSetDoc = (docRef: DocRef, data: any) => {
  const table = docRef.collection;
  const id = docRef.id;
  const pkField = table === 'users' ? 'uid' : 'id';
  
  const tableData = getLocalStorageTable(table);
  const existingIndex = tableData.findIndex(row => String(row[pkField]) === String(id));
  
  // Handle increments if any
  const resolvedData = { ...data };
  for (const key of Object.keys(resolvedData)) {
    const val = resolvedData[key];
    if (val && typeof val === 'object' && val.type === 'increment') {
      const existingRow = existingIndex > -1 ? tableData[existingIndex] : null;
      const currentVal = existingRow ? Number(existingRow[key] || 0) : 0;
      resolvedData[key] = currentVal + val.value;
    }
  }
  
  const snakeData = toSnakeCase(resolvedData);
  snakeData[pkField] = id;
  
  if (existingIndex > -1) {
    tableData[existingIndex] = { ...tableData[existingIndex], ...snakeData };
  } else {
    tableData.push(snakeData);
  }
  saveLocalStorageTable(table, tableData);
};

const fallbackUpdateDoc = (docRef: DocRef, data: any) => {
  const table = docRef.collection;
  const id = docRef.id;
  const pkField = table === 'users' ? 'uid' : 'id';
  
  const tableData = getLocalStorageTable(table);
  const existingIndex = tableData.findIndex(row => String(row[pkField]) === String(id));
  
  if (existingIndex > -1) {
    // Handle increments
    const resolvedData = { ...data };
    for (const key of Object.keys(resolvedData)) {
      const val = resolvedData[key];
      if (val && typeof val === 'object' && val.type === 'increment') {
        const existingRow = tableData[existingIndex];
        const currentVal = existingRow ? Number(existingRow[key] || 0) : 0;
        resolvedData[key] = currentVal + val.value;
      }
    }
    
    const snakeData = toSnakeCase(resolvedData);
    tableData[existingIndex] = { ...tableData[existingIndex], ...snakeData };
    saveLocalStorageTable(table, tableData);
  }
};

const fallbackDeleteDoc = (docRef: DocRef) => {
  const table = docRef.collection;
  const id = docRef.id;
  const pkField = table === 'users' ? 'uid' : 'id';
  
  const tableData = getLocalStorageTable(table);
  const filtered = tableData.filter(row => String(row[pkField]) !== String(id));
  saveLocalStorageTable(table, filtered);
};

const fallbackGetDoc = (docRef: DocRef) => {
  const table = docRef.collection;
  const id = docRef.id;
  const pkField = table === 'users' ? 'uid' : 'id';
  
  const tableData = getLocalStorageTable(table);
  const found = tableData.find(row => String(row[pkField]) === String(id));
  const camelData = found ? toCamelCase(found) : null;
  
  return {
    exists: () => found !== undefined && found !== null,
    id: id,
    data: () => camelData,
  };
};

const fallbackGetDocs = (queryObj: QueryRef | CollectionRef) => {
  const table = queryObj.collection;
  const pkField = table === 'users' ? 'uid' : 'id';
  let tableData = getLocalStorageTable(table);
  
  if (queryObj.type === 'query') {
    const constraints = (queryObj as QueryRef).constraints;
    for (const c of constraints) {
      if (c.type === 'where') {
        const snakeField = camelToSnake(c.field);
        tableData = tableData.filter(row => {
          const val = row[snakeField];
          if (c.op === '==') {
            return String(val) === String(c.value);
          } else if (c.op === '>=') {
            return Number(val) >= Number(c.value);
          } else if (c.op === '<=') {
            return Number(val) <= Number(c.value);
          } else if (c.op === '>') {
            return Number(val) > Number(c.value);
          } else if (c.op === '<') {
            return Number(val) < Number(c.value);
          } else if (c.op === 'array-contains' || c.op === 'in') {
            const list = Array.isArray(c.value) ? c.value : [c.value];
            return list.map(String).includes(String(val));
          }
          return true;
        });
      } else if (c.type === 'orderBy') {
        const snakeField = camelToSnake(c.field);
        tableData.sort((a, b) => {
          const valA = a[snakeField];
          const valB = b[snakeField];
          if (typeof valA === 'number' && typeof valB === 'number') {
            return c.direction === 'asc' ? valA - valB : valB - valA;
          }
          const strA = String(valA || '');
          const strB = String(valB || '');
          return c.direction === 'asc' ? strA.localeCompare(strB) : strB.localeCompare(strA);
        });
      } else if (c.type === 'limit') {
        tableData = tableData.slice(0, c.count);
      }
    }
  }
  
  const docs = tableData.map((row: any) => {
    const camelData = toCamelCase(row);
    return {
      id: String(row[pkField] || ''),
      exists: () => true,
      data: () => camelData,
    };
  });
  
  return {
    docs,
    length: docs.length,
    empty: docs.length === 0,
  };
};

// ----------------------------------------------------
// DB Operations
// ----------------------------------------------------
export const setDoc = async (docRef: DocRef, data: any, options?: { merge?: boolean }) => {
  const table = docRef.collection;
  if (fallbackTables.has(table)) {
    fallbackSetDoc(docRef, data);
    return;
  }
  
  try {
    const id = docRef.id;
    const pkField = table === 'users' ? 'uid' : 'id';
    
    let resolvedData = toSnakeCase(data);
    resolvedData = await resolveIncrements(table, id, resolvedData);
    resolvedData[pkField] = id;
    
    const { error } = await supabase
      .from(table)
      .upsert(resolvedData, { onConflict: pkField });
      
    if (error) throw error;
  } catch (error) {
    if (isTableNotFound(error)) {
      console.warn(`⚠️ Table "${table}" not found in Supabase. Switching to dynamic local storage fallback.`);
      fallbackTables.add(table);
      fallbackSetDoc(docRef, data);
    } else {
      handleFirestoreError(error, OperationType.WRITE, docRef.path);
    }
  }
};

export const updateDoc = async (docRef: DocRef, data: any) => {
  const table = docRef.collection;
  if (fallbackTables.has(table)) {
    fallbackUpdateDoc(docRef, data);
    return;
  }

  try {
    const id = docRef.id;
    const pkField = table === 'users' ? 'uid' : 'id';
    
    let resolvedData = toSnakeCase(data);
    resolvedData = await resolveIncrements(table, id, resolvedData);
    
    const { error } = await supabase
      .from(table)
      .update(resolvedData)
      .eq(pkField, id);
      
    if (error) throw error;
  } catch (error) {
    if (isTableNotFound(error)) {
      console.warn(`⚠️ Table "${table}" not found in Supabase. Switching to dynamic local storage fallback.`);
      fallbackTables.add(table);
      fallbackUpdateDoc(docRef, data);
    } else {
      handleFirestoreError(error, OperationType.UPDATE, docRef.path);
    }
  }
};

export const deleteDoc = async (docRef: DocRef) => {
  const table = docRef.collection;
  if (fallbackTables.has(table)) {
    fallbackDeleteDoc(docRef);
    return;
  }

  try {
    const id = docRef.id;
    const pkField = table === 'users' ? 'uid' : 'id';
    
    const { error } = await supabase
      .from(table)
      .delete()
      .eq(pkField, id);
      
    if (error) throw error;
  } catch (error) {
    if (isTableNotFound(error)) {
      console.warn(`⚠️ Table "${table}" not found in Supabase. Switching to dynamic local storage fallback.`);
      fallbackTables.add(table);
      fallbackDeleteDoc(docRef);
    } else {
      handleFirestoreError(error, OperationType.DELETE, docRef.path);
    }
  }
};

export const getDoc = async (docRef: DocRef) => {
  const table = docRef.collection;
  if (fallbackTables.has(table)) {
    return fallbackGetDoc(docRef);
  }

  try {
    const id = docRef.id;
    const pkField = table === 'users' ? 'uid' : 'id';
    
    const { data, error } = await supabase
      .from(table)
      .select('*')
      .eq(pkField, id)
      .maybeSingle();
      
    if (error) throw error;
    
    const camelData = data ? toCamelCase(data) : null;
    
    return {
      exists: () => data !== null && data !== undefined,
      id: id,
      data: () => camelData,
    };
  } catch (error) {
    if (isTableNotFound(error)) {
      console.warn(`⚠️ Table "${table}" not found in Supabase. Switching to dynamic local storage fallback.`);
      fallbackTables.add(table);
      return fallbackGetDoc(docRef);
    } else {
      handleFirestoreError(error, OperationType.GET, docRef.path);
    }
  }
};

const buildSupabaseQuery = (queryObj: QueryRef | CollectionRef) => {
  const table = queryObj.collection;
  let q = supabase.from(table).select('*');
  
  if (queryObj.type === 'query') {
    const constraints = (queryObj as QueryRef).constraints;
    for (const c of constraints) {
      if (c.type === 'where') {
        const snakeField = camelToSnake(c.field);
        if (c.op === '==') {
          q = q.eq(snakeField, c.value);
        } else if (c.op === '>=') {
          q = q.gte(snakeField, c.value);
        } else if (c.op === '<=') {
          q = q.lte(snakeField, c.value);
        } else if (c.op === '>') {
          q = q.gt(snakeField, c.value);
        } else if (c.op === '<') {
          q = q.lt(snakeField, c.value);
        } else if (c.op === 'array-contains' || c.op === 'in') {
          q = q.in(snakeField, Array.isArray(c.value) ? c.value : [c.value]);
        }
      } else if (c.type === 'orderBy') {
        const snakeField = camelToSnake(c.field);
        q = q.order(snakeField, { ascending: c.direction === 'asc' });
      } else if (c.type === 'limit') {
        q = q.limit(c.count);
      }
    }
  }
  return q;
};

export const getDocs = async (queryObj: QueryRef | CollectionRef) => {
  const table = queryObj.collection;
  if (fallbackTables.has(table)) {
    return fallbackGetDocs(queryObj);
  }

  try {
    const q = buildSupabaseQuery(queryObj);
    const { data, error } = await q;
    
    if (error) throw error;
    
    const docs = (data || []).map((row: any) => {
      const camelData = toCamelCase(row);
      const pkField = table === 'users' ? 'uid' : 'id';
      const docId = String(row[pkField] || '');
      return {
        id: docId,
        exists: () => true,
        data: () => camelData,
      };
    });
    
    return {
      docs,
      length: docs.length,
      empty: docs.length === 0,
    };
  } catch (error) {
    if (isTableNotFound(error)) {
      console.warn(`⚠️ Table "${table}" not found in Supabase. Switching to dynamic local storage fallback.`);
      fallbackTables.add(table);
      return fallbackGetDocs(queryObj);
    } else {
      handleFirestoreError(error, OperationType.LIST, table);
    }
  }
};


export const onSnapshot = (
  target: DocRef | CollectionRef | QueryRef,
  callback: (snap: any) => void,
  errCallback?: (err: any) => void
) => {
  const table = target.collection;
  let active = true;
  
  const fetchAndNotify = async () => {
    if (!active) return;
    try {
      if (target.type === 'doc') {
        const snap = await getDoc(target as DocRef);
        if (active) callback(snap);
      } else {
        const snap = await getDocs(target as CollectionRef | QueryRef);
        if (active) callback(snap);
      }
    } catch (err) {
      console.error("onSnapshot fetch error:", err);
      if (errCallback) errCallback(err);
    }
  };
  
  fetchAndNotify();

  // Listen to window 'storage' events for local fallback reactivity
  const handleStorageChange = () => {
    if (fallbackTables.has(table)) {
      fetchAndNotify();
    }
  };
  window.addEventListener('storage', handleStorageChange);
  
  const channelId = `realtime:${table}:${Math.random().toString(36).substring(2, 9)}`;
  const channel = supabase
    .channel(channelId)
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: table },
      () => {
        fetchAndNotify();
      }
    )
    .subscribe((status) => {
      if (status === 'SUBSCRIBED') {
        console.log(`📡 Realtime active on table: ${table}`);
      }
    });
    
  return () => {
    active = false;
    window.removeEventListener('storage', handleStorageChange);
    supabase.removeChannel(channel);
  };
};

export const writeBatch = (dbObj: any) => {
  return {
    set: (docRef: any, data: any) => {},
    update: (docRef: any, data: any) => {},
    delete: (docRef: any) => {},
    commit: async () => {}
  };
};

// ----------------------------------------------------
// Authentication
// ----------------------------------------------------
export const getRedirectUrl = () => {
  if (typeof window !== 'undefined') {
    // Detect if we are running in an Android/webview context or if user came from mobile app
    const urlParams = new URLSearchParams(window.location.search);
    const isMobileApp = urlParams.get('platform') === 'android' || 
                        navigator.userAgent.toLowerCase().includes('sapcone') || 
                        navigator.userAgent.toLowerCase().includes('android');
    
    if (isMobileApp) {
      return "sapcone://auth/callback";
    }
    
    const origin = window.location.origin;
    if (origin.includes('localhost') || origin.includes('127.0.0.1')) {
      // Prevent redirecting to localhost in preview/testing environments
      return "https://ais-pre-matzexhkokecbdix3cqrzf-449341993460.europe-west2.run.app";
    }
    return origin;
  }
  return "https://ais-pre-matzexhkokecbdix3cqrzf-449341993460.europe-west2.run.app";
};

export const signInWithEmailAndPassword = async (authObj: any, email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return {
    user: {
      uid: data.user?.id || '',
      email: data.user?.email || '',
    }
  };
};

export const createUserWithEmailAndPassword = async (authObj: any, email: string, password: string) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: getRedirectUrl(),
    },
  });
  if (error) throw error;
  return {
    user: {
      uid: data.user?.id || '',
      email: data.user?.email || '',
    }
  };
};

export const sendPasswordResetEmail = async (authObj: any, email: string) => {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: getRedirectUrl(),
  });
  if (error) throw error;
};

export const signOut = async (authObj: any) => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const onAuthStateChanged = (authObj: any, callback: (user: FirebaseUser | null) => void) => {
  supabase.auth.getSession().then(({ data: { session } }) => {
    if (session?.user) {
      callback({
        uid: session.user.id,
        email: session.user.email || null,
      });
    } else {
      callback(null);
    }
  });

  const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
    if (session?.user) {
      callback({
        uid: session.user.id,
        email: session.user.email || null,
      });
    } else {
      callback(null);
    }
  });

  return () => {
    subscription.unsubscribe();
  };
};
