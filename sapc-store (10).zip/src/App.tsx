import React, { useState, useEffect } from 'react';
import { auth, db, onAuthStateChanged, signOut, doc, onSnapshot, setDoc, getDoc, FirebaseUser } from './supabase';
import { UserProfile, INVESTMENT_LEVELS } from './types';
import { motion, AnimatePresence } from 'motion/react';

// Import our modular components
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import Tasks from './components/Tasks';
import Predictions from './components/Predictions';
import FootballHub from './components/FootballHub';
import DepositWithdraw from './components/DepositWithdraw';
import ReferralCenter from './components/ReferralCenter';
import AdminPanel from './components/AdminPanel';
import Settings from './components/Settings';

import { 
  Home, Tv, Zap, Wallet, Users, ShieldAlert, LogOut, Trophy,
  ChevronRight, Sparkles, CheckCircle2, AlertCircle, RefreshCw, BadgeInfo, Bell,
  Settings as SettingsIcon
} from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Navigation active tab
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Football fixture preset parameters for AI prediction page transition
  const [presetHomeTeam, setPresetHomeTeam] = useState<string>('');
  const [presetAwayTeam, setPresetAwayTeam] = useState<string>('');
  const [presetFixtureId, setPresetFixtureId] = useState<string>('');
  
  // Levels Upgrade state / modal
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [upgradeError, setUpgradeError] = useState<string | null>(null);
  const [upgradeSuccess, setUpgradeSuccess] = useState<string | null>(null);

  const [globalConfig, setGlobalConfig] = useState<any>({
    providerName: "SAPC STORE"
  });

  useEffect(() => {
    const unsubGlobal = onSnapshot(doc(db, 'settings', 'global'), (snap) => {
      if (snap.exists()) {
        setGlobalConfig(snap.data());
      }
    });
    return () => unsubGlobal();
  }, []);

  // Catch referral code parameter from URL link
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const refCode = params.get('ref');
    if (refCode) {
      localStorage.setItem('sapc_referred_by', refCode.toUpperCase());
    }
  }, []);

  // Listen to Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setCurrentUser(firebaseUser);
        
        // Listen to User Profile in Firestore
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        
        const unsubProfile = onSnapshot(userDocRef, async (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data() as UserProfile;
            const emailLower = (firebaseUser.email || data.email || '').trim().toLowerCase();
            const uidLower = (firebaseUser.uid || data.uid || '').trim();
            const isTargetAdmin = emailLower === 'djafloekemoda@gmail.com' || uidLower === 'user-pnoa46pn1';
            
            if (isTargetAdmin) {
              if (data.role !== 'admin' || !data.email) {
                data.role = 'admin';
                if (!data.email) {
                  data.email = 'djafloekemoda@gmail.com';
                }
                await setDoc(userDocRef, { role: 'admin', email: data.email }, { merge: true });
              }
            } else {
              // Safely revoke unrequested admin accesses
              if (data.role === 'admin') {
                data.role = 'user';
                await setDoc(userDocRef, { role: 'user' }, { merge: true });
              }
            }
            setProfile(data);
          } else {
            // Helper profile fallback creation in case document got desynced
            const emailValue = firebaseUser.email || '';
            const uidVal = firebaseUser.uid || '';
            const isTargetAdmin = emailValue.trim().toLowerCase() === 'djafloekemoda@gmail.com' || uidVal === 'user-pnoa46pn1';
            const newProfile: UserProfile = {
              uid: firebaseUser.uid,
              email: emailValue || (isTargetAdmin ? 'djafloekemoda@gmail.com' : ''),
              username: isTargetAdmin ? 'SAPC STORE' : (emailValue ? emailValue.split('@')[0] : 'User'),
              balance: 0,
              totalEarnings: 0,
              totalReferrals: 0,
              level: 0,
              referralCode: 'SAPC' + Math.floor(100000 + Math.random() * 900000),
              referredBy: localStorage.getItem('sapc_referred_by') || undefined,
              createdAt: new Date().toISOString(),
              role: isTargetAdmin ? 'admin' : 'user',
              status: 'active'
            };
            await setDoc(userDocRef, newProfile);
            setProfile(newProfile);
          }
          setLoading(false);
        });

        return () => unsubProfile();
      } else {
        setCurrentUser(null);
        setProfile(null);
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleSignOut = async () => {
    if (window.confirm("Je una uhakika unataka kuondoka kwenye akaunti?")) {
      await signOut(auth);
    }
  };

  const handleNavigation = (tab: string) => {
    if (!tab) return;
    if (tab.startsWith('http://') || tab.startsWith('https://')) {
      window.open(tab, '_blank', 'noopener,noreferrer');
    } else if (tab === 'levels') {
      setShowUpgradeModal(true);
    } else {
      setActiveTab(tab);
    }
  };

  const handleAnalyzeFixture = (home: string, away: string, matchId: string) => {
    setPresetHomeTeam(home);
    setPresetAwayTeam(away);
    setPresetFixtureId(matchId);
    setActiveTab('prediction');
  };

  const forceRefreshProfile = async () => {
    if (!currentUser) return;
    const snap = await getDoc(doc(db, 'users', currentUser.uid));
    if (snap.exists()) {
      setProfile(snap.data() as UserProfile);
    }
  };

  // Direct upgrade using current Balance
  const handleUpgradeWithBalance = async (levelNumber: number) => {
    if (!profile) return;
    setUpgradeError(null);
    setUpgradeSuccess(null);

    const targetLevel = INVESTMENT_LEVELS[levelNumber];
    if (profile.balance < targetLevel.cost) {
      setUpgradeError(`Salio lako halitoshi! Kujiunga na Level ${levelNumber} unahitaji TZS ${targetLevel.cost.toLocaleString()}. Tafadhali ongeza salio kwanza au chagua njia nyingine.`);
      return;
    }

    try {
      const userRef = doc(db, 'users', profile.uid);
      await setDoc(userRef, {
        balance: profile.balance - targetLevel.cost,
        level: levelNumber
      }, { merge: true });

      // Save Upgrade Notification log
      const logId = 'log-upgrade-' + Math.random().toString(36).substring(2, 10);
      await setDoc(doc(db, 'notifications', logId), {
        id: logId,
        userId: profile.uid,
        title: `Level Upgraded to Level ${levelNumber}!`,
        message: `Hongera mno! Umefanikiwa kujiunga na Level ${levelNumber} (${targetLevel.title}) kwa TZS ${targetLevel.cost.toLocaleString()}. Sasa kamilisha kazi hadi ${targetLevel.tasksCount} kwa siku upokee mapato makubwa!`,
        type: 'general',
        read: false,
        createdAt: new Date().toISOString()
      });

      // Keep activity logs audit trail
      const actId = 'log-act-upgrade-' + Math.random().toString(36).substring(2, 10);
      await setDoc(doc(db, 'activity_logs', actId), {
        id: actId,
        userId: profile.uid,
        username: profile.username,
        email: profile.email,
        type: 'level_upgrade',
        amount: targetLevel.cost,
        message: `Mwanachama ${profile.username} amejiboresha kuwa Level ${levelNumber} (${targetLevel.title}) kwa TZS ${targetLevel.cost.toLocaleString()} kwa kutumia Salio la Akaunti.`,
        createdAt: new Date().toISOString()
      });

      setUpgradeSuccess(`Hongera! Umefanikiwa kukua hadi Level ${levelNumber} kwa kutumia salio la akaunti yako.`);
      setShowUpgradeModal(false);
      forceRefreshProfile();
    } catch (err: any) {
      console.error(err);
      setUpgradeError("Kosa limetokea wakati wa kukuza kiwango.");
    }
  };

  const isWhiteBg = globalConfig?.whiteThemeMode === 'enabled';

  const getTabStyle = (tabId: string) => {
    const isActive = activeTab === tabId;
    const styleObj: React.CSSProperties = {};
    if (isActive) {
      if (globalConfig.activeTabBgColor) {
        styleObj.backgroundColor = globalConfig.activeTabBgColor;
        styleObj.borderRadius = '12px';
        styleObj.padding = '4px 10px';
      }
      if (globalConfig.activeTabTextColor) {
        styleObj.color = globalConfig.activeTabTextColor;
      }
    } else {
      if (globalConfig.inactiveTabBgColor) {
        styleObj.backgroundColor = globalConfig.inactiveTabBgColor;
        styleObj.borderRadius = '12px';
        styleObj.padding = '4px 10px';
      }
      if (globalConfig.inactiveTabTextColor) {
        styleObj.color = globalConfig.inactiveTabTextColor;
      }
    }
    return styleObj;
  };

  // Show Loading Screens during load
  if (loading) {
    return (
      <div className={`flex flex-col items-center justify-center min-h-screen font-mono transition-all duration-300 ${
        isWhiteBg ? 'bg-[#F3F4F6] text-[#0F1115]' : 'bg-[#0A0A0C] text-white'
      }`}>
        <RefreshCw className="w-10 h-10 text-orange-400 animate-spin mb-4" />
        <p className={`text-xs uppercase tracking-widest ${isWhiteBg ? 'text-[#0F1115]/50' : 'text-white/40'}`}>SAPC Store Inapakia...</p>
      </div>
    );
  }

  // Not logged in state
  if (!currentUser || !profile) {
    return (
      <div className={`min-h-screen font-sans transition-all duration-300 ${
        isWhiteBg ? 'bg-[#F3F4F6] text-[#0F1115]' : 'bg-[#0A0A0C] text-white'
      }`}>
        <Auth onSuccess={(prof) => setProfile(prof)} />
      </div>
    );
  }

  // Logged in state: Main Application Layout Frame
  return (
    <div 
      style={globalConfig.bgImageUrl ? { backgroundImage: `url(${globalConfig.bgImageUrl})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundAttachment: 'fixed' } : {}}
      className={`min-h-screen flex flex-col justify-between selection:bg-orange-500 selection:text-black font-sans transition-all duration-300 ${
        isWhiteBg 
          ? 'bg-[#F3F4F6] text-[#0F1115]' 
          : 'bg-[#0A0A0C] text-white'
      }`}
    >
      
      {/* A. STATUS TOP HEADER */}
      <header className={`sticky top-0 z-30 backdrop-blur-md border-b shadow-lg px-4 py-3 flex justify-between items-center transition-all ${
        isWhiteBg 
          ? 'bg-white/90 border-black/10 text-[#0F1115]' 
          : 'bg-[#0A0A0C]/90 border-white/10 text-white'
      }`}>
        <div className="flex items-center gap-2">
          {/* Visual premium logo icon - admin custom logo or fallback */}
          {globalConfig.logoUrl ? (
            <img 
              src={globalConfig.logoUrl} 
              alt="Logo" 
              className="w-8 h-8 rounded-lg object-cover shadow-lg"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-gradient-to-tr from-orange-500 to-orange-300 text-black font-black text-lg shadow-lg shadow-orange-500/10">
              {globalConfig.providerName ? globalConfig.providerName.trim().charAt(0).toUpperCase() : 'S'}
            </div>
          )}
          <div>
            <h1 className={`text-sm font-black tracking-tight uppercase sm:text-base ${isWhiteBg ? 'text-black' : 'text-white'}`}>
              {globalConfig.providerName ? (
                <>
                  {globalConfig.providerName.split(' ')[0]} <span className="text-orange-400">{globalConfig.providerName.split(' ').slice(1).join(' ') || 'TIPS'}</span>
                </>
              ) : (
                <>
                  SAPC <span className="text-orange-400">STORE</span>
                </>
              )}
            </h1>
            <span className={`block text-[8px] font-mono tracking-widest uppercase ${isWhiteBg ? 'text-[#0F1115]/50' : 'text-white/40'}`}>
              Tanzania No.1 Mobile App
            </span>
          </div>
        </div>

        {/* Level tag & sign-out */}
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowUpgradeModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-orange-500 to-orange-400 hover:opacity-90 active:scale-95 transition text-black font-extrabold text-[10px] uppercase rounded-lg shadow-lg accent-glow"
          >
            Kiwango {profile.level} <Sparkles className="w-3 h-3 text-black fill-current animate-pulse" />
          </button>

          <button
            onClick={handleSignOut}
            className={`p-1.5 rounded-lg border transition ${
              isWhiteBg ? 'bg-black/5 hover:bg-black/10 text-red-500 border-black/10' : 'bg-white/5 hover:bg-white/10 text-red-400 border-white/10'
            }`}
            title="Log Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* B. MAIN INTERACTIVE VIEWER FRAME */}
      <main className="flex-grow max-w-lg w-full mx-auto px-4 py-6 pb-24 space-y-6">
        
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.18 }}
          >
            {activeTab === 'dashboard' && (
              <Dashboard profile={profile} onNavigate={handleNavigation} />
            )}

            {activeTab === 'football' && (
              <FootballHub 
                profile={profile} 
                onNavigate={handleNavigation} 
                onAnalyzeFixture={handleAnalyzeFixture} 
              />
            )}

            {activeTab === 'prediction' && (
              <Predictions 
                profile={profile} 
                onRefreshProfile={forceRefreshProfile} 
              />
            )}

            {activeTab === 'settings' && (
              <Settings 
                profile={profile} 
                onRefreshProfile={forceRefreshProfile} 
                onNavigate={handleNavigation} 
              />
            )}

            {activeTab === 'admin' && profile && (profile.role === 'admin' || profile.email?.trim().toLowerCase() === 'djafloekemoda@gmail.com' || profile.uid === 'user-pnoa46pn1') && (
              <AdminPanel onRefreshProfile={forceRefreshProfile} />
            )}
          </motion.div>
        </AnimatePresence>

      </main>

       {/* C. BOTTOM MOBILE NAVIGATION RAIL */}
      <nav className={`fixed bottom-0 left-0 right-0 z-40 backdrop-blur-lg border-t px-2 py-1.5 shadow-xl flex justify-around items-center max-w-lg mx-auto rounded-t-2xl animate-fade-in transition-all ${
        isWhiteBg 
          ? 'bg-white/90 border-black/10 text-black shadow-black/5' 
          : 'bg-[#0A0A0C]/90 border-white/10 text-white'
      }`}>
        <button
          onClick={() => setActiveTab('dashboard')}
          style={getTabStyle('dashboard')}
          className={`flex flex-col items-center gap-0.5 p-1.5 transition cursor-pointer ${
            activeTab === 'dashboard' ? (globalConfig.activeTabTextColor ? '' : 'text-orange-400 font-bold scale-105') : (globalConfig.inactiveTabTextColor ? '' : 'text-white/60 hover:text-white')
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[9px] font-mono uppercase tracking-wider">Home</span>
        </button>

        <button
          onClick={() => setActiveTab('football')}
          style={getTabStyle('football')}
          className={`flex flex-col items-center gap-0.5 p-1.5 transition cursor-pointer ${
            activeTab === 'football' ? (globalConfig.activeTabTextColor ? '' : 'text-orange-400 font-bold scale-105') : (globalConfig.inactiveTabTextColor ? '' : 'text-white/60 hover:text-white')
          }`}
        >
          <Tv className="w-5 h-5" />
          <span className="text-[9px] font-mono uppercase tracking-wider">Soka</span>
        </button>

        <button
          onClick={() => setActiveTab('prediction')}
          style={getTabStyle('prediction')}
          className={`flex flex-col items-center gap-0.5 p-1.5 transition cursor-pointer ${
            activeTab === 'prediction' ? (globalConfig.activeTabTextColor ? '' : 'text-orange-400 font-bold scale-105') : (globalConfig.inactiveTabTextColor ? '' : 'text-white/60 hover:text-white')
          }`}
        >
          <Trophy className="w-5 h-5" />
          <span className="text-[9px] font-mono uppercase tracking-wider">My Bets</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          style={getTabStyle('settings')}
          className={`flex flex-col items-center gap-0.5 p-1.5 transition cursor-pointer ${
            activeTab === 'settings' ? (globalConfig.activeTabTextColor ? '' : 'text-orange-400 font-bold scale-105') : (globalConfig.inactiveTabTextColor ? '' : 'text-white/60 hover:text-white')
          }`}
        >
          <SettingsIcon className="w-5 h-5" />
          <span className="text-[9px] font-mono uppercase tracking-wider">Profile</span>
        </button>

        {/* Admin Tab (conditionally rendered) */}
        {profile && (profile.role === 'admin' || profile.email?.trim().toLowerCase() === 'djafloekemoda@gmail.com' || profile.uid === 'user-pnoa46pn1') && (
          <button
            onClick={() => setActiveTab('admin')}
            style={getTabStyle('admin')}
            className={`flex flex-col items-center gap-0.5 p-1.5 transition text-purple-400 cursor-pointer ${
              activeTab === 'admin' ? 'text-purple-300 font-bold scale-105' : 'opacity-70 hover:opacity-100'
            }`}
          >
            <ShieldAlert className="w-5 h-5" />
            <span className="text-[9px] font-mono uppercase tracking-wider">Admin</span>
          </button>
        )}
      </nav>

      {/* D. INVESTMENT LEVELS UPGRADE MODAL */}
      <AnimatePresence>
        {showUpgradeModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-[#0A0A0C] border border-white/10 p-6 rounded-3xl max-w-sm w-full space-y-5 shadow-2xl relative glass accent-glow"
            >
              <div className="flex justify-between items-center border-b border-white/10 pb-3">
                <h3 className="text-sm font-black text-orange-400 uppercase tracking-wider">Kuboresha Kiwango cha Akaunti Momento</h3>
                <button 
                  onClick={() => { setShowUpgradeModal(false); setUpgradeError(null); setUpgradeSuccess(null); }}
                  className="text-xs text-white/40 hover:text-white font-mono"
                >
                  Funga
                </button>
              </div>

              {upgradeError && (
                <div className="flex items-start p-3 text-sm rounded bg-red-500/10 border border-red-500/20 text-red-400 gap-2 font-mono">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                  <span className="text-xs">{upgradeError}</span>
                </div>
              )}

              {upgradeSuccess && (
                <div className="flex items-start p-3 text-sm rounded bg-orange-500/10 border border-orange-500/20 text-orange-400 gap-2 font-mono">
                  <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
                  <span className="text-xs">{upgradeSuccess}</span>
                </div>
              )}

              <p className="text-xs text-white/60 font-mono leading-relaxed">
                Tazama picha ya maelekezo hapa chini ili kupandisha kiwango chako cha akaunti:
              </p>

              {/* Customizable Payment and Upgrade Instructions Image */}
              <div className="space-y-4">
                {globalConfig.levelPaymentImageUrl ? (
                  <div className="rounded-2xl overflow-hidden border border-white/10 bg-[#0A0A0C]">
                    <img 
                      src={globalConfig.levelPaymentImageUrl} 
                      alt="Maelekezo ya Malipo ya Viwango" 
                      className="w-full h-auto object-contain max-h-[350px]"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                ) : (
                  <div className="p-6 text-center border border-dashed border-white/10 rounded-2xl bg-white/[0.01] space-y-2">
                    <div className="w-12 h-12 bg-orange-500/10 border border-orange-500/20 text-orange-400 rounded-full flex items-center justify-center mx-auto text-xl font-sans">
                      📸
                    </div>
                    <p className="text-xs text-white/80 font-bold font-mono">Picha ya Malipo Haijawekwa Bado</p>
                    <p className="text-[10px] text-white/40 font-sans">Tafadhali Admin weka Picha ya malipo kwenye Panel ya Admin.</p>
                  </div>
                )}

                {/* Additional manual support instructions */}
                <div className="p-3.5 rounded-2xl bg-orange-500/5 border border-orange-500/10 text-[11px] leading-relaxed text-white/75 font-mono">
                  <span className="text-[#FB923C] font-black block uppercase mb-1">💡 Jinsi ya Kujiunga:</span>
                  Tafadhali fuata maelekezo ya picha hapo juu kufanya malipo. Baada ya kulipa, wasiliana nasi kupitia <span className="text-orange-400">Huduma kwa Wateja (Support)</span> ukiwa na ID ya mwamala au risiti ili akaunti yako ihuishwe mara moja.
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
