export const SUPABASE_SQL_SCHEMA = `-- SAPC STORE - Supabase PostgreSQL Schema & Migrations
-- This file defines all necessary tables, constraints, security policies, and performance indexes.

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- =========================================================
-- 1. Table: users
-- =========================================================
create table if not exists public.users (
    uid text primary key,
    email text not null unique,
    username text not null,
    balance numeric(15, 2) not null default 0.00,
    total_earnings numeric(15, 2) not null default 0.00,
    total_referrals integer not null default 0,
    level integer not null default 0,
    referral_code text not null unique,
    referred_by text,
    vip_until timestamp with time zone,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    role text not null default 'user' check (role in ('user', 'admin')),
    device_info text,
    status text not null default 'active' check (status in ('active', 'suspended'))
);

comment on table public.users is 'User profiles, balances, earning levels and vip prediction packages.';

-- Create an internal admin look up table to avoid RLS recursion on public.users
create table if not exists public.admin_users (
    uid text primary key,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

comment on table public.admin_users is 'Lookup table to identify admin users and prevent row-level security recursion.';

-- Enable RLS on admin_users
alter table public.admin_users enable row level security;

-- Policies for admin_users
create policy "Anyone can read admin_users" 
    on public.admin_users for select 
    using (true);

-- Trigger function to automatically keep admin_users in sync with users
create or replace function public.sync_admin_users()
returns trigger as $$
begin
  if new.role = 'admin' then
    insert into public.admin_users (uid) values (new.uid)
    on conflict (uid) do nothing;
  else
    delete from public.admin_users where uid = new.uid;
  end if;
  return new;
end;
$$ language plpgsql security definer;

-- Trigger on users insertion or role updates
create trigger trigger_sync_admin_users
after insert or update of role on public.users
for each row execute function public.sync_admin_users();

-- Trigger for deletion
create or replace function public.sync_admin_users_delete()
returns trigger as $$
begin
  delete from public.admin_users where uid = old.uid;
  return old;
end;
$$ language plpgsql security definer;

create trigger trigger_sync_admin_users_delete
after delete on public.users
for each row execute function public.sync_admin_users_delete();

-- Seed existing admin users
insert into public.admin_users (uid)
select uid from public.users where role = 'admin'
on conflict (uid) do nothing;

-- Helper function to check if a user is an admin without triggering RLS recursion
create or replace function public.is_admin(user_uid text)
returns boolean as $$
begin
  return exists (
    select 1 from public.admin_users
    where uid = user_uid
  );
end;
$$ language plpgsql security definer set search_path = public;

comment on function public.is_admin is 'Security definer helper to check if uid has role admin to prevent policy recursion.';

-- Enable Row Level Security (RLS)
alter table public.users enable row level security;

-- Policies for public.users
create policy "Users can read own profile" 
    on public.users for select 
    using (auth.uid()::text = uid);

create policy "Users can update own details" 
    on public.users for update 
    using (auth.uid()::text = uid);

create policy "Admins have full write control on users" 
    on public.users for all 
    using (
        public.is_admin(auth.uid()::text)
    );

-- Allow public inserts for registration
create policy "Enable registration for new accounts"
    on public.users for insert
    with check (true);


-- =========================================================
-- 2. Table: predictions
-- =========================================================
create table if not exists public.predictions (
    id text primary key,
    user_id text not null references public.users(uid) on delete cascade,
    home_team text not null,
    away_team text not null,
    is_vip boolean not null default false,
    response jsonb not null, -- contains win probabilities, overUnder, btts, correctScore, analysis
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

comment on table public.predictions is 'Football game analyses and AI predictions generated for users.';

alter table public.predictions enable row level security;

-- Policies for public.predictions
create policy "Users can view own predictions"
    on public.predictions for select
    using (auth.uid()::text = user_id);

create policy "Users can request/insert predictions"
    on public.predictions for insert
    with check (auth.uid()::text = user_id);

create policy "Admins can manage predictions"
    on public.predictions for all
    using (
        public.is_admin(auth.uid()::text)
    );


-- =========================================================
-- 3. Table: matches
-- =========================================================
create table if not exists public.matches (
    id text primary key,
    league text not null,
    home_team text not null,
    away_team text not null,
    status text not null, -- LIVE, UPCOMING, FINISHED
    match_time text not null,
    score text not null default '? - ?',
    odds jsonb not null default '{}'::jsonb,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

comment on table public.matches is 'Live scores and upcoming football fixture details cached on system.';

alter table public.matches enable row level security;

create policy "Signed-in users can read matches"
    on public.matches for select
    using (auth.role() = 'authenticated');

create policy "Admins can full write matches"
    on public.matches for all
    using (
        public.is_admin(auth.uid()::text)
    );


-- =========================================================
-- 4. Table: subscriptions
-- =========================================================
create table if not exists public.subscriptions (
    id text primary key,
    user_id text not null references public.users(uid) on delete cascade,
    type text not null, -- week, month
    amount numeric(15, 2) not null,
    status text not null default 'active', -- active, expired
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    expires_at timestamp with time zone not null
);

comment on table public.subscriptions is 'VIP Prediction Plans & Subscriptions.';

alter table public.subscriptions enable row level security;

create policy "Users can read own subscriptions"
    on public.subscriptions for select
    using (auth.uid()::text = user_id);

create policy "Users can insert own subscriptions"
    on public.subscriptions for insert
    with check (auth.uid()::text = user_id);

create policy "Admins can manage subscriptions"
    on public.subscriptions for all
    using (
        public.is_admin(auth.uid()::text)
    );


-- =========================================================
-- 5. Table: deposits (Payments In)
-- =========================================================
create table if not exists public.deposits (
    id text primary key,
    user_id text not null references public.users(uid) on delete cascade,
    username text not null,
    amount numeric(15, 2) not null,
    phone text not null,
    payment_method text not null, -- M-Pesa, Airtel Money, Tigo Pesa, Halo Pesa, PesaPal
    transaction_id text not null unique,
    status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone
);

comment on table public.deposits is 'Deposit / Add money requests submitted by store members.';

alter table public.deposits enable row level security;

create policy "Users can check own deposits"
    on public.deposits for select
    using (auth.uid()::text = user_id);

create policy "Users can submit deposits"
    on public.deposits for insert
    with check (auth.uid()::text = user_id);

create policy "Admins can manage deposits"
    on public.deposits for all
    using (
        public.is_admin(auth.uid()::text)
    );


-- =========================================================
-- 6. Table: withdrawals (Payments Out)
-- =========================================================
create table if not exists public.withdrawals (
    id text primary key,
    user_id text not null references public.users(uid) on delete cascade,
    username text not null,
    amount numeric(15, 2) not null,
    phone text not null,
    payment_method text not null,
    status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    updated_at timestamp with time zone
);

comment on table public.withdrawals is 'Withdraw money requests submitted by store members.';

alter table public.withdrawals enable row level security;

create policy "Users can see own withdrawals"
    on public.withdrawals for select
    using (auth.uid()::text = user_id);

create policy "Users can request withdrawals"
    on public.withdrawals for insert
    with check (auth.uid()::text = user_id);

create policy "Admins can oversee withdrawals"
    on public.withdrawals for all
    using (
        public.is_admin(auth.uid()::text)
    );


-- =========================================================
-- 7. Table: notifications
-- =========================================================
create table if not exists public.notifications (
    id text primary key,
    user_id text not null references public.users(uid) on delete cascade,
    title text not null,
    message text not null,
    type text not null default 'general',
    read boolean not null default false,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

comment on table public.notifications is 'In-app transaction receipts and service status updates.';

alter table public.notifications enable row level security;

create policy "Users can fetch own notifications"
    on public.notifications for select
    using (auth.uid()::text = user_id);

create policy "Users can update read status"
    on public.notifications for update
    using (auth.uid()::text = user_id);

create policy "Admins can push notifications"
    on public.notifications for insert
    with check (true); -- Allow system system-wide inserts


-- =========================================================
-- 8. Table: video_tasks (Rewards Tasks)
-- =========================================================
create table if not exists public.video_tasks (
    id text primary key,
    title text not null,
    video_url text not null,
    reward_amount numeric(15, 2) not null,
    duration integer not null default 30, -- in seconds
    active boolean not null default true,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

comment on table public.video_tasks is 'Watch-to-Earn video tasks managed by platform admin.';

alter table public.video_tasks enable row level security;

create policy "Authenticated users can fetch task videos"
    on public.video_tasks for select
    using (auth.role() = 'authenticated');

create policy "Admins can execute actions on video tasks"
    on public.video_tasks for all
    using (
        public.is_admin(auth.uid()::text)
    );


-- =========================================================
-- 9. Table: task_completions
-- =========================================================
create table if not exists public.task_completions (
    id text primary key,
    user_id text not null references public.users(uid) on delete cascade,
    task_type text not null,
    task_id text not null,
    reward numeric(15, 2) not null,
    date text not null, -- YYYY-MM-DD
    completed_at timestamp with time zone default timezone('utc'::text, now()) not null
);

comment on table public.task_completions is 'Receipt logs showing completed chores and paid earnings.';

alter table public.task_completions enable row level security;

create policy "Members can audit own completions"
    on public.task_completions for select
    using (auth.uid()::text = user_id);

create policy "Members can execute task completions"
    on public.task_completions for insert
    with check (auth.uid()::text = user_id);


-- =========================================================
-- 10. Table: activity_logs (Audit Trails)
-- =========================================================
create table if not exists public.activity_logs (
    id text primary key,
    user_id text references public.users(uid) on delete set null,
    username text,
    email text,
    type text not null,
    amount numeric(15, 2),
    message text not null,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

comment on table public.activity_logs is 'System audit timeline monitoring upgrades, registrations and payment updates.';

alter table public.activity_logs enable row level security;

create policy "Members can view the activity streams"
    on public.activity_logs for select
    using (auth.role() = 'authenticated');

create policy "Members can write activity trails"
    on public.activity_logs for insert
    with check (true);


-- =========================================================
-- 11. Table: system_settings (Platform core)
-- =========================================================
create table if not exists public.system_settings (
    id text primary key,
    football_api_key text,
    live_scores_api text,
    fixtures_api text,
    odds_api text,
    openai_api_key text,
    gemini_api_key text,
    deepseek_api_key text,
    claude_api_key text,
    m_pesa_number text,
    airtel_number text,
    tigo_number text,
    halo_number text,
    daily_withdraw_limit numeric(15, 2) default 50000.00
);

comment on table public.system_settings is 'Confidential API keys and mobile deposit telephone wallets.';

alter table public.system_settings enable row level security;

create policy "Admins have full access to secrets"
    on public.system_settings for all
    using (
        public.is_admin(auth.uid()::text)
    );

create policy "Members can fetch public billing wallets"
    on public.system_settings for select
    using (auth.role() = 'authenticated');


-- =========================================================
-- 12. Table: betslips (TIPS and coupons)
-- =========================================================
create table if not exists public.betslips (
    id text primary key,
    bookmaker text not null,
    provider text not null,
    odds numeric(15, 2) not null,
    stake numeric(15, 2) not null,
    expires_in_secs integer not null,
    accuracy text not null,
    booking_code text not null,
    cost numeric(15, 2) not null,
    games jsonb not null default '[]'::jsonb,
    status text not null default 'active' check (status in ('active', 'won', 'lost')),
    created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

comment on table public.betslips is 'Premium Tips, coupons and Betting Slips available for unlocking.';

alter table public.betslips enable row level security;

create policy "Anyone can read betslips"
    on public.betslips for select
    using (true);

create policy "Admins can manage betslips"
    on public.betslips for all
    using (
        public.is_admin(auth.uid()::text)
    );


-- =========================================================
-- Create Database Indexes for high performance
-- =========================================================
create index if not exists idx_users_referral_code on public.users(referral_code);
create index if not exists idx_deposits_user on public.deposits(user_id);
create index if not exists idx_withdrawals_user on public.withdrawals(user_id);
create index if not exists idx_notifications_user on public.notifications(user_id);
create index if not exists idx_task_completions_user_date on public.task_completions(user_id, date);
create index if not exists idx_predictions_user on public.predictions(user_id);
create index if not exists idx_betslips_created on public.betslips(created_at);
`;
