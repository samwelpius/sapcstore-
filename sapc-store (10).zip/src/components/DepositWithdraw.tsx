import React, { useState, useEffect } from 'react';
import { db, collection, doc, query, where, setDoc, updateDoc, increment, onSnapshot } from '../supabase';
import { UserProfile, DepositRequest } from '../types';
import { 
  ArrowUpRight, Wallet, ShieldCheck, AlertCircle, CheckCircle2, 
  Copy, Smartphone, CircleDollarSign, Receipt, Info, ArrowRight
} from 'lucide-react';

interface DepositWithdrawProps {
  profile: UserProfile;
  initialMode: 'deposit' | 'withdraw';
  onRefreshProfile: () => void;
  onNavigate: (tab: string) => void;
}

export default function DepositWithdraw({ profile, onRefreshProfile, onNavigate }: DepositWithdrawProps) {
  // Exclusively lock to deposit mode on user's absolute directive
  const mode = 'deposit';
  
  // Deposit manual elements
  const [depAmount, setDepAmount] = useState('');
  const [depPhone, setDepPhone] = useState((profile as any).defaultPhone || '');
  const [depMethod, setDepMethod] = useState((profile as any).defaultNetwork || 'M-Pesa');
  const [depTxnId, setDepTxnId] = useState('');

  // PesaPal details
  const [onlineAmount, setOnlineAmount] = useState('');
  const [onlineEmail, setOnlineEmail] = useState(profile.email || '');
  const [onlineLoading, setOnlineLoading] = useState(false);
  const [onlineRedirectUrl, setOnlineRedirectUrl] = useState<string | null>(null);

  // checkout wizards
  const [inAppGatewayStep, setInAppGatewayStep] = useState<'form' | 'processing' | 'iframe' | 'success'>('form');
  const [inAppProgressStatus, setInAppProgressStatus] = useState('');

  // list records
  const [depositsList, setDepositsList] = useState<DepositRequest[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Recipient phone details config 
  const [operatorRecipients, setOperatorRecipients] = useState<Record<string, { phone: string; name: string }>>({
    'M-Pesa': { phone: '0768 112 233', name: 'SAPC STORE LTD (Vodacom)' },
    'Airtel Money': { phone: '0682 445 566', name: 'SAPC STORE LTD (Airtel)' },
    'Tigo Pesa': { phone: '0715 889 900', name: 'SAPC STORE LTD (Tigo)' },
    'HaloPesa': { phone: '0621 334 455', name: 'SAPC STORE LTD (Halotel)' },
  });

  useEffect(() => {
    // Sync recipient details dynamically from database values
    const unsubConfig = onSnapshot(doc(db, 'settings', 'global'), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setOperatorRecipients({
          'M-Pesa': { phone: data.mPesaNumber || '0768 112 233', name: 'SAPC STORE LTD (Vodacom)' },
          'Airtel Money': { phone: data.airtelNumber || '0682 445 566', name: 'SAPC STORE LTD (Airtel)' },
          'Tigo Pesa': { phone: data.tigoNumber || '0715 889 900', name: 'SAPC STORE LTD (Tigo)' },
          'HaloPesa': { phone: data.haloNumber || '0621 334 455', name: 'SAPC STORE LTD (Halotel)' },
        });
      }
    });

    return () => unsubConfig();
  }, []);

  useEffect(() => {
    if (!profile.uid) return;

    // fetch deposits history
    const depQuery = query(collection(db, 'deposits'), where('userId', '==', profile.uid));
    const unsubDeps = onSnapshot(depQuery, (snapshot) => {
      setDepositsList(snapshot.docs.map(doc => doc.data() as DepositRequest).sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ));
    });

    return () => unsubDeps();
  }, [profile.uid]);

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const amount = Number(depAmount);
    if (!amount || amount < 2000) {
      setErrorMsg("Kiwango cha chini cha kuweka ni TZS 2,000");
      return;
    }

    if (!depPhone || depPhone.length < 9) {
      setErrorMsg("Weka namba sahihi ya simu uliyotuma fedha");
      return;
    }

    if (!depTxnId || depTxnId.trim().length < 6) {
      setErrorMsg("Tafadhali weka Operator Transaction ID halisi.");
      return;
    }

    setLoading(true);
    try {
      const depId = 'dep-' + Math.random().toString(36).substring(2, 10);
      const newDeposit: DepositRequest = {
        id: depId,
        userId: profile.uid,
        username: profile.username,
        amount: amount,
        phone: depPhone.trim(),
        paymentMethod: depMethod,
        transactionId: depTxnId.trim().toUpperCase(),
        status: 'pending',
        createdAt: new Date().toISOString()
      };

      await setDoc(doc(db, 'deposits', depId), newDeposit);
      
      const logId = 'log-dep-' + Math.random().toString(36).substring(2, 10);
      await setDoc(doc(db, 'activity_logs', logId), {
        id: logId,
        userId: profile.uid,
        username: profile.username,
        email: profile.email,
        type: 'deposit_request',
        amount: amount,
        message: `Mwanachama ${profile.username} ameomba kuongeza salio la TZS ${amount.toLocaleString()} kupitia ${depMethod}. Namba ya simu: ${depPhone.trim()}, ID ya Mwamala: ${depTxnId.trim().toUpperCase()}`,
        createdAt: new Date().toISOString()
      });

      const notifyId = 'notif-' + Math.random().toString(36).substring(2, 10);
      await setDoc(doc(db, 'notifications', notifyId), {
        id: notifyId,
        userId: profile.uid,
        title: 'Ombi la Kuweka Limewasilishwa',
        message: `Ombi lako la kuweka TZS ${amount.toLocaleString()} kupitia ${depMethod} (TX: ${depTxnId.toUpperCase()}) limepokelewa na linasubiri uhakiki wa Admin hapa Tanzania.`,
        type: 'deposit',
        read: false,
        createdAt: new Date().toISOString()
      });

      setSuccessMsg(`Ombi lako limepokelewa! Tafadhali subiri hadi dakika 15 kwa malipo yako kuthibitishwa na kuongezwa katika salio lako.`);
      setDepAmount('');
      setDepPhone('');
      setDepTxnId('');
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "Imeshindwa kuwasilisha ombi la kuweka pesa.");
    } finally {
      setLoading(false);
    }
  };

  const handlePesapalPay = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    setOnlineRedirectUrl(null);
    
    const amount = Number(onlineAmount);
    if (!amount || amount < 2000) {
      setErrorMsg("Kiwango cha chini cha kuweka ni TZS 2,005");
      return;
    }

    if (!onlineEmail || !onlineEmail.includes('@')) {
      setErrorMsg("Barua pepe (Email) halisi inahitajika ili kukamilisha malipo.");
      return;
    }

    setOnlineLoading(true);
    setInAppGatewayStep('processing');
    setInAppProgressStatus("Inatengeneza muunganisho salama wa PesaPal...");

    try {
      const response = await fetch("/api/payment/pesapal/initiate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          amount,
          email: onlineEmail,
          phone: (profile as any).defaultPhone || "0755000000",
          uid: profile.uid,
          username: profile.username
        })
      });

      let data: any = {};
      const contentType = response.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        data = await response.json();
      } else {
        const textResponse = await response.text();
        console.error("SAPC Deposit PesaPal failure. Non-JSON Response:", textResponse, "Status Code:", response.status);
        throw new Error(`Kosa la mfumo (Hali ${response.status}): Lango la malipo limefeli kurudisha data sahihi. Wasiliana na msimamizi au thibitisha usanidi wako wa Netlify.`);
      }

      if (!response.ok || data.error) {
        throw new Error(data.error || "PesaPal API Error");
      }

      if (data.redirect_url) {
        setOnlineRedirectUrl(data.redirect_url);
        
        const depId = data.merchant_reference || ('dep-online-' + Math.random().toString(36).substring(2, 10));
        const newDeposit: DepositRequest = {
          id: depId,
          userId: profile.uid,
          username: profile.username,
          amount: amount,
          phone: "PESAPAL_IFRAME",
          paymentMethod: "PesaPal Online",
          transactionId: depId,
          status: 'pending',
          createdAt: new Date().toISOString()
        };
        await setDoc(doc(db, 'deposits', depId), newDeposit);

        const logId = 'log-dep-' + Math.random().toString(36).substring(2, 11);
        await setDoc(doc(db, 'activity_logs', logId), {
          id: logId,
          userId: profile.uid,
          username: profile.username,
          email: profile.email,
          type: 'deposit_request',
          amount: amount,
          message: `Mwanachama ${profile.username} ameanzisha malipo ya TZS ${amount.toLocaleString()} kupitia lango la mtandaoni la PesaPal.`,
          createdAt: new Date().toISOString()
        });

        setInAppGatewayStep('iframe');
      } else {
        throw new Error("Imeshindwa kupata URL ya malipo kutoka PesaPal.");
      }
    } catch (err: any) {
      console.error("SAPC Deposit: PesaPal initiation failed with error:", err);
      setErrorMsg(err.message || "Imeshindwa kuunganisha na mfumo wa malipo wa PesaPal. Tafadhali weka kwa kutumia Njia Mbadala hapo chini.");
      setInAppGatewayStep('form');
    } finally {
      setOnlineLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert("Imenakiliwa: " + text);
  };

  return (
    <div className="space-y-6">
      
      {/* Title block */}
      <div className="bg-emerald-500/10 border border-emerald-500/20 px-4 py-3 rounded-2xl flex items-center gap-2">
        <Wallet className="w-5 h-5 text-emerald-400 shrink-0" />
        <p className="text-xs font-bold text-white uppercase tracking-wider font-mono">NJIA YA MALIPO / KUWEKA SALIO</p>
      </div>

      {errorMsg && (
        <div className="flex items-start p-3 text-xs rounded bg-red-500/10 border border-red-500/20 text-red-500 gap-2 font-mono">
          <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="flex items-start p-3 text-xs rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 gap-2 font-mono">
          <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* 1. SECURE DEPOSIT WIDGET */}
      <div className="space-y-6 animate-fade-in text-xs font-sans">
        
        <div className="bg-[#0D0E12] border-2 border-orange-500/30 p-5 rounded-2xl space-y-4 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-48 h-48 bg-orange-500/5 rounded-full filter blur-3xl pointer-events-none" />
          
          <div className="flex justify-between items-center border-b border-white/10 pb-3">
            <div>
              <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5 font-mono">
                <ShieldCheck className="w-5 h-5 text-orange-400" /> SECURE IN-APP CHECKOUT
              </h3>
              <p className="text-[10px] text-white/50 font-mono mt-0.5">
                Malipo ya haraka na salama papo hapo kupitia PesaPal (M-pesa, Tigo, Airtel au Cards)
              </p>
            </div>
            <span className="inline-flex text-[9px] font-black text-orange-400 bg-orange-500/10 border border-orange-500/20 px-2.5 py-1 rounded-full uppercase font-mono animate-pulse">PESAPAL INTERNAL</span>
          </div>

          {inAppGatewayStep === 'form' && (
            <form onSubmit={handlePesapalPay} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-white/50 uppercase font-mono">Kiasi (Amount in TZS)</label>
                  <div className="relative">
                    <input
                      type="number"
                      value={onlineAmount}
                      onChange={(e) => setOnlineAmount(e.target.value)}
                      placeholder="M.f: 5000"
                      className="w-full px-3 py-2 pl-7 bg-black/50 border border-white/10 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-orange-500 transition-colors"
                      required
                      min="2000"
                    />
                    <span className="absolute left-2.5 top-2 text-xs text-white/30 font-bold font-mono">T</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-white/50 uppercase font-mono">Barua Pepe (Email)</label>
                  <input
                    type="email"
                    value={onlineEmail}
                    onChange={(e) => setOnlineEmail(e.target.value)}
                    placeholder="mteja@dominika.com"
                    className="w-full px-3 py-2 bg-black/50 border border-white/10 rounded-xl text-xs font-mono text-white focus:outline-none focus:border-orange-500 transition-colors"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-orange-500 hover:bg-orange-400 text-black font-black rounded-xl text-xs uppercase tracking-wide cursor-pointer transition-all flex items-center justify-center gap-1.5"
              >
                ENDELEA NA MALIPO YA PESAPAL <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {inAppGatewayStep === 'processing' && (
            <div className="py-12 text-center space-y-4 font-mono">
              <div className="w-10 h-10 border-2 border-orange-500/25 border-t-orange-550 border-t-orange-500 rounded-full animate-spin mx-auto" />
              <p className="text-[10px] text-white/40 uppercase animate-pulse">{inAppProgressStatus || "Inatayarisha muunganisho wa PesaPal..."}</p>
            </div>
          )}

          {inAppGatewayStep === 'iframe' && onlineRedirectUrl && (
            <div className="space-y-4 font-mono">
              <div className="p-3 bg-emerald-500/5 border border-emerald-500/30 rounded-xl space-y-1 text-[10px] text-emerald-400">
                <p className="font-bold flex items-center gap-1"><ShieldCheck className="w-4 h-4" /> MUUNGANISHO WA PESAPAL UMEWEZESHWA</p>
                <p className="text-white/40 font-sans text-[8.5px]">Tafadhali kamilisha malipo yako kwenye kisanduku salama kilicho chini:</p>
              </div>

              <div className="relative w-full rounded-2xl border border-white/10 overflow-hidden bg-white shadow-xl">
                <iframe 
                  src={onlineRedirectUrl} 
                  className="w-full h-[520px] bg-white border-0" 
                  allow="payment"
                  title="PesaPal live wallet frame"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setInAppGatewayStep('form');
                    setOnlineRedirectUrl(null);
                    setOnlineAmount('');
                  }}
                  className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 text-white rounded-xl uppercase font-bold"
                >
                  Futa PesaPal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onRefreshProfile();
                    setInAppGatewayStep('form');
                    setOnlineRedirectUrl(null);
                    setOnlineAmount('');
                    setSuccessMsg("Malipo yako yamesajiliwa kwa ajili ya uhakiki kiotomatiki.");
                  }}
                  className="flex-1 py-2.5 bg-orange-500 text-black font-black rounded-xl uppercase"
                >
                  NIMEKUMALIZA MALIPO (REFRESH)
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Divider */}
        <div className="relative flex py-1 items-center">
          <div className="flex-grow border-t border-white/5"></div>
          <span className="flex-shrink mx-4 text-[9px] text-white/30 font-bold font-mono uppercase">Njia Mbadala ya Simu (Manual)</span>
          <div className="flex-grow border-t border-white/5"></div>
        </div>

        {/* Instructions and Manual details */}
        <div className="bg-[#0F1116] border border-white/10 p-5 rounded-2xl space-y-4 font-mono text-xs">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1">
            Hatua za Kuhamisha Mapato (Manual Instructions) <Info className="w-4 h-4 text-orange-400" />
          </h4>

          <div className="space-y-3 font-sans text-white/40 leading-relaxed text-[10.5px]">
            <p>1. Chagua mtoa mtandao (Operator) chini, fanya muamala kwenda kwenye namba na jina linaloonekana:</p>
            
            <div className="p-4 bg-black/40 rounded-xl border border-white/5 font-mono space-y-2 text-xs">
              <div className="flex justify-between">
                <span>Mtandao (Operator):</span>
                <select
                  value={depMethod}
                  onChange={(e) => setDepMethod(e.target.value)}
                  className="bg-[#0A0A0C] border border-white/15 px-2 py-1 text-white rounded focus:outline-none text-[11px]"
                >
                  <option value="M-Pesa">Vodacom M-Pesa</option>
                  <option value="Airtel Money">Airtel Money</option>
                  <option value="Tigo Pesa">Tigo Pesa</option>
                  <option value="HaloPesa">Halotel HaloPesa</option>
                </select>
              </div>

              <div className="flex justify-between items-center py-1.5 border-t border-b border-white/5">
                <span>Namba:</span>
                <div className="flex items-center gap-1 bg-[#0A0A0C] px-2 py-0.5 rounded border border-white/10 text-white font-bold">
                  <span>{operatorRecipients[depMethod]?.phone}</span>
                  <button onClick={() => copyToClipboard(operatorRecipients[depMethod]?.phone)} className="text-[#FB923C]"><Copy className="w-3 h-3" /></button>
                </div>
              </div>

              <div className="flex justify-between">
                <span>Jina:</span>
                <span className="text-white font-bold">{operatorRecipients[depMethod]?.name}</span>
              </div>
            </div>

            <p>2. Baada ya kukamilisha kuhamisha fedha, jaza fomu iliyopo chini ili uhakiki ukamilike:</p>
          </div>

          {/* Manual proof input form */}
          <form onSubmit={handleDepositSubmit} className="space-y-3.5 pt-1">
            <div className="space-y-1">
              <label className="text-[9px] text-white/40 uppercase font-bold">Kiasi Kilichotumwa (TZS)</label>
              <div className="relative">
                <input
                  type="number"
                  value={depAmount}
                  onChange={(e) => setDepAmount(e.target.value)}
                  placeholder="Mfano: 5000"
                  className="w-full px-3 py-2 pl-8 bg-black/40 border border-white/15 rounded-xl text-white text-xs focus:outline-none"
                  required
                />
                <CircleDollarSign className="absolute left-2.5 top-2.5 w-4 h-4 text-white/20" />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] text-white/40 uppercase font-bold">Namba ya Simu Uliyotumia</label>
              <div className="relative">
                <input
                  type="text"
                  value={depPhone}
                  onChange={(e) => setDepPhone(e.target.value)}
                  placeholder="07xxxxxxxx"
                  className="w-full px-3 py-2 pl-8 bg-black/40 border border-white/15 rounded-xl text-white text-xs focus:outline-none"
                  required
                />
                <Smartphone className="absolute left-2.5 top-2.5 w-4 h-4 text-white/20" />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] text-white/40 uppercase font-bold">Msimbo wa Operator (Transaction ID)</label>
              <div className="relative">
                <input
                  type="text"
                  value={depTxnId}
                  onChange={(e) => setDepTxnId(e.target.value)}
                  placeholder="Kutoka kwenye SMS ya muamala"
                  className="w-full px-3 py-2 pl-8 bg-black/40 border border-white/15 rounded-xl text-white text-xs focus:outline-none uppercase"
                  required
                />
                <Receipt className="absolute left-2.5 top-2.5 w-4 h-4 text-white/20" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-orange-500 hover:bg-orange-400 disabled:bg-white/5 text-black font-black uppercase text-xs rounded-xl"
            >
              {loading ? "INAHAKIKI..." : "TUMA OMBI LA UHAKIKI WA MANUAL"}
            </button>
          </form>
        </div>

        {/* Dynamic transaction proof log mapping */}
        <div className="bg-[#0F1116] border border-white/5 p-4 rounded-2xl space-y-3 font-mono">
          <h4 className="text-xs font-bold text-white uppercase tracking-wider">Historia ya Walisiti (Receipts Log)</h4>
          
          <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
            {depositsList.length === 0 ? (
              <p className="text-[10px] text-white/40 text-center py-4">Huna kumbukumbu za kuweka malipo bado.</p>
            ) : (
              depositsList.map((dep) => (
                <div key={dep.id} className="p-3 bg-black/45 rounded-xl flex justify-between items-center text-[10px]">
                  <div>
                    <p className="font-bold text-white">Weka: {dep.paymentMethod}</p>
                    <p className="text-[8.5px] text-[#FFFFFF]/35">TXID: {dep.transactionId}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-orange-450 text-[#FB923C]">+{dep.amount.toLocaleString()} TZS</p>
                    <span className="text-[8.5px] uppercase text-orange-400">{dep.status}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
