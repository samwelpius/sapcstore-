import React, { useState, useEffect } from 'react';
import { db, collection, doc, updateDoc, setDoc, deleteDoc, onSnapshot, increment, fallbackTables } from '../supabase';
import { UserProfile } from '../types';
import { SUPABASE_SQL_SCHEMA } from '../data/supabaseSql';
import { 
  Users, Zap, Shield, RefreshCw, Plus, Trash2, CheckCircle2,
  Edit2, Search, Save, Info, Clock, AlertTriangle, ToggleLeft, Layers, FileCode, Check,
  Wallet, CircleDollarSign, XCircle, Copy, TrendingUp, Filter, Database
} from 'lucide-react';

interface AdminPanelProps {
  onRefreshProfile: () => void;
}

interface Betslip {
  id: string;
  bookmaker: 'SportyBet' | 'BetPawa';
  provider: string;
  odds: number;
  stake: number;
  expiresInSecs: number; 
  accuracy: string;
  bookingCode: string;
  cost: number;
  games: {
    match: string;
    prediction: string;
    odds: number;
  }[];
  status?: 'active' | 'won' | 'lost';
}

export default function AdminPanel({ onRefreshProfile }: AdminPanelProps) {
  // Navigation tabs
  const [adminTab, setAdminTab] = useState<'users' | 'tps' | 'texts' | 'deposits' | 'db'>('users');

  // Master States
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [slips, setSlips] = useState<Betslip[]>([]);
  const [deposits, setDeposits] = useState<any[]>([]);
  const [globalConfig, setGlobalConfig] = useState<any>({
    welcomeTitle: "Karibu SAPC TIPS",
    welcomeSubtitle: "Njia salama na rahisi ya kuvuna kupitia mikeka ya uhakika ya soka kila siku.",
    premiumHeader: "MIKEKA YA PREMIUM YA SAPC TIPS",
    premiumPromo: "Mchongo wa Leo: Mikeka ya PREMIUM imewekwa tayari kukulaza na ushindi mnono! 🔥",
    providerName: "SAPC TIPS",
    mPesaNumber: "0768 112 233",
    airtelNumber: "0682 445 566",
    tigoNumber: "0715 889 900",
    haloNumber: "0621 334 455",
    themeStyle: "cosmic_orange",
    slipsSorting: "countdown",
    slipsLayout: "one_column"
  });

  // Search parameters
  const [userSearch, setUserSearch] = useState('');
  const [depositSearch, setDepositSearch] = useState('');
  const [depositStatusFilter, setDepositStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [copiedSql, setCopiedSql] = useState(false);

  // Status and Alerts
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);

  // --- EDIT USER STATE ---
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editBalance, setEditBalance] = useState('0');
  const [editLevel, setEditLevel] = useState('0');
  const [editRole, setEditRole] = useState<'user' | 'admin'>('user');
  const [editStatus, setEditStatus] = useState<'active' | 'suspended'>('active');

  // --- POST NEW PRE-MATCH SLIP (TPS) STATE ---
  const [bookmaker, setBookmaker] = useState<'SportyBet' | 'BetPawa'>('SportyBet');
  const [accuracy, setAccuracy] = useState('99% Sure');
  const [slipCost, setSlipCost] = useState('2000');
  const [slipOdds, setSlipOdds] = useState('14.50');
  const [slipStake, setSlipStake] = useState('10000');
  const [matchHoursInFuture, setMatchHoursInFuture] = useState('12'); // Expiration timer ("mda wa mechi")
  const [bookingCode, setBookingCode] = useState('SB-TZ-88998');
  const [slipStatus, setSlipStatus] = useState<'active' | 'won' | 'lost'>('active');

  // --- EDIT SLIP STATE ---
  const [editingSlipId, setEditingSlipId] = useState<string | null>(null);
  const [editSlipBookmaker, setEditSlipBookmaker] = useState<'SportyBet' | 'BetPawa'>('SportyBet');
  const [editSlipAccuracy, setEditSlipAccuracy] = useState('99% Sure');
  const [editSlipCost, setEditSlipCost] = useState('2000');
  const [editSlipOdds, setEditSlipOdds] = useState('14.50');
  const [editSlipStake, setEditSlipStake] = useState('10000');
  const [editSlipHours, setEditSlipHours] = useState('12');
  const [editSlipBookingCode, setEditSlipBookingCode] = useState('SB-TZ-88998');
  const [editSlipOperationMode, setEditSlipOperationMode] = useState<'teams' | 'code_only'>('teams');
  const [editSlipGames, setEditSlipGames] = useState<{ match: string; prediction: string; odds: number; status?: 'active' | 'won' | 'lost' }[]>([]);
  const [editNewMatchName, setEditNewMatchName] = useState('');
  const [editNewMatchPrediction, setEditNewMatchPrediction] = useState('');
  const [editNewMatchOdds, setEditNewMatchOdds] = useState('1.50');
  const [editNewMatchStatus, setEditNewMatchStatus] = useState<'active' | 'won' | 'lost'>('active');
  const [editSlipStatus, setEditSlipStatus] = useState<'active' | 'won' | 'lost'>('active');

  // Slip Mode Operation: Team list OR booking code only ("kuwe na opesheni mbili kuweka majina ya timu ama kuweka book code")
  const [slipOperationMode, setSlipOperationMode] = useState<'teams' | 'code_only'>('teams');

  // Matches lists for Teams mode
  const [matches, setMatches] = useState<{ match: string; prediction: string; odds: number; status?: 'active' | 'won' | 'lost' }[]>([
    { match: 'Simba vs Yanga', prediction: 'Home Win', odds: 1.85, status: 'active' }
  ]);
  const [newMatchName, setNewMatchName] = useState('');
  const [newMatchPrediction, setNewMatchPrediction] = useState('');
  const [newMatchOdds, setNewMatchOdds] = useState('1.50');
  const [newMatchStatus, setNewMatchStatus] = useState<'active' | 'won' | 'lost'>('active');

  // Listen to Firestore databases
  useEffect(() => {
    // 1. Listen to Users
    const unsubUsers = onSnapshot(collection(db, 'users'), (snap) => {
      setUsers(snap.docs.map(doc => doc.data() as UserProfile));
    });

    // 2. Listen to SLips
    const unsubSlips = onSnapshot(collection(db, 'betslips'), (snap) => {
      setSlips(snap.docs.map(doc => doc.data() as Betslip));
    });

    // 3. Listen to Global configuration settings
    const unsubGlobal = onSnapshot(doc(db, 'settings', 'global'), (snap) => {
      if (snap.exists()) {
        setGlobalConfig({
          ...globalConfig,
          ...snap.data()
        });
      }
    });

    // 4. Listen to Deposits
    const unsubDeposits = onSnapshot(collection(db, 'deposits'), (snap) => {
      setDeposits(snap.docs.map(doc => doc.data()).sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ));
    });

    return () => {
      unsubUsers();
      unsubSlips();
      unsubGlobal();
      unsubDeposits();
    };
  }, []);

  const triggerAlert = (type: 'success' | 'err', msg: string) => {
    if (type === 'success') {
      setSuccessMsg(msg);
      setErrorMsg(null);
    } else {
      setErrorMsg(msg);
      setSuccessMsg(null);
    }
    setTimeout(() => {
      setSuccessMsg(null);
      setErrorMsg(null);
    }, 4500);
  };

  // --- USER CONTROLS ---
  const handleStartEditUser = (u: UserProfile) => {
    setEditingUserId(u.uid);
    setEditBalance(String(u.balance || 0));
    setEditLevel(String(u.level || 0));
    setEditRole(u.role || 'user');
    setEditStatus((u as any).status || 'active');
  };

  const handleSaveUser = async (uid: string) => {
    setActionLoading(true);
    try {
      const parsedBalance = parseFloat(editBalance) || 0;
      const parsedLevel = parseInt(editLevel) || 0;

      await updateDoc(doc(db, 'users', uid), {
        balance: parsedBalance,
        level: parsedLevel,
        role: editRole,
        status: editStatus
      });

      setEditingUserId(null);
      triggerAlert('success', "Taarifa za mtumiaji zimesasishwa kikamilifu!");
      onRefreshProfile();
    } catch (err: any) {
      triggerAlert('err', "Imeshindwa kusasisha: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteUser = async (uid: string) => {
    if (!window.confirm("Je, una uhakika unataka kufuta kabisa mtumiaji huyu? Kitendo hiki hakina thibitisho mbadala.")) return;
    setActionLoading(true);
    try {
      await deleteDoc(doc(db, 'users', uid));
      triggerAlert('success', "Mtumiaji amefutwa kwenye mfumo.");
    } catch (err: any) {
      triggerAlert('err', "Kosa wakati wa kufuta mtumiaji: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // --- TPS/SLIPS CONTROLS ---
  const handleAddMatchToNewSlip = () => {
    if (!newMatchName.trim() || !newMatchPrediction.trim()) {
      triggerAlert('err', "Tafadhali jaza majina ya timu na ubashiri kwanza.");
      return;
    }
    const parsedOdds = parseFloat(newMatchOdds) || 1.1;
    setMatches([...matches, {
      match: newMatchName.trim(),
      prediction: newMatchPrediction.trim(),
      odds: parsedOdds,
      status: newMatchStatus
    }]);

    setNewMatchName('');
    setNewMatchPrediction('');
    setNewMatchOdds('1.50');
    setNewMatchStatus('active');
  };

  const handleRemoveMatchFromNewSlip = (index: number) => {
    setMatches(matches.filter((_, i) => i !== index));
  };

  const handlePostPremiumSlip = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionLoading(true);

    try {
      const parsedOdds = parseFloat(slipOdds) || 2.0;
      const parsedStake = parseFloat(slipStake) || 5000;
      const parsedCost = parseFloat(slipCost) || 1000;
      const parsedHours = parseFloat(matchHoursInFuture) || 12;
      const slipExpiresSecs = Math.round(parsedHours * 3600);

      const generatedId = 'slip-' + Math.random().toString(36).substring(2, 9);
      
      // Determine what matching list elements to populate based on the select mode ("Opesheni mbili: kuweka majina ya timu au book code")
      const finalGamesList = slipOperationMode === 'teams' ? matches : [];

      const newSlip: Betslip = {
        id: generatedId,
        bookmaker,
        provider: globalConfig.providerName || "SAPC TIPS",
        odds: parsedOdds,
        stake: parsedStake,
        expiresInSecs: slipExpiresSecs,
        accuracy,
        bookingCode: bookingCode.trim(),
        cost: parsedCost,
        games: finalGamesList,
        status: slipStatus
      };

      await setDoc(doc(db, 'betslips', generatedId), newSlip);

      // Clean slip parameters
      setBookingCode('');
      setMatches([]);
      setSlipStatus('active');
      triggerAlert('success', "Premium VIP betslip imepostiwa kikamilifu!");
    } catch (err: any) {
      triggerAlert('err', "Imeshindwa kupost mkeka: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleDeleteSlip = async (slipId: string) => {
    if (!window.confirm("Je, una uhakika unataka kukata/kufuta mkeka huu wa Premium?")) return;
    setActionLoading(true);
    try {
      await deleteDoc(doc(db, 'betslips', slipId));
      triggerAlert('success', "Premium betslip imefutwa kikamilifu.");
    } catch (err: any) {
      triggerAlert('err', "Imeshindwa kufuta: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // --- EDIT SLIP CONTROLS ---
  const handleStartEditSlip = (slip: Betslip) => {
    setEditingSlipId(slip.id);
    setEditSlipBookmaker(slip.bookmaker);
    setEditSlipAccuracy(slip.accuracy);
    setEditSlipCost(String(slip.cost));
    setEditSlipOdds(String(slip.odds));
    setEditSlipStake(String(slip.stake));
    setEditSlipHours(String(slip.expiresInSecs ? slip.expiresInSecs / 3600 : 12));
    setEditSlipBookingCode(slip.bookingCode);
    setEditSlipOperationMode(slip.games && slip.games.length > 0 ? 'teams' : 'code_only');
    setEditSlipGames(slip.games || []);
    setEditSlipStatus(slip.status || 'active');
  };

  const handleAddMatchToEditSlip = () => {
    if (!editNewMatchName.trim() || !editNewMatchPrediction.trim()) {
      triggerAlert('err', "Tafadhali jaza majina ya timu na ubashiri kwanza.");
      return;
    }
    const parsedOdds = parseFloat(editNewMatchOdds) || 1.1;
    setEditSlipGames([...editSlipGames, {
      match: editNewMatchName.trim(),
      prediction: editNewMatchPrediction.trim(),
      odds: parsedOdds,
      status: editNewMatchStatus
    }]);
    setEditNewMatchName('');
    setEditNewMatchPrediction('');
    setEditNewMatchOdds('1.50');
    setEditNewMatchStatus('active');
  };

  const handleRemoveMatchFromEditSlip = (index: number) => {
    setEditSlipGames(editSlipGames.filter((_, i) => i !== index));
  };

  const handleSaveSlipEdits = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingSlipId) return;
    setActionLoading(true);
    try {
      const parsedOdds = parseFloat(editSlipOdds) || 2.0;
      const parsedStake = parseFloat(editSlipStake) || 5000;
      const parsedCost = parseFloat(editSlipCost) || 1000;
      const parsedHours = parseFloat(editSlipHours) || 12;
      const slipExpiresSecs = Math.round(parsedHours * 3600);

      const finalGamesList = editSlipOperationMode === 'teams' ? editSlipGames : [];

      const updatedSlip: Betslip = {
        id: editingSlipId,
        bookmaker: editSlipBookmaker,
        provider: globalConfig.providerName || "SAPC TIPS",
        odds: parsedOdds,
        stake: parsedStake,
        expiresInSecs: slipExpiresSecs,
        accuracy: editSlipAccuracy,
        bookingCode: editSlipBookingCode.trim(),
        cost: parsedCost,
        games: finalGamesList,
        status: editSlipStatus
      };

      await setDoc(doc(db, 'betslips', editingSlipId), updatedSlip);
      setEditingSlipId(null);
      triggerAlert('success', "Taarifa za Premium VIP betslip zimesasishwa kikamilifu! ✨");
    } catch (err: any) {
      triggerAlert('err', "Imeshindwa kusasisha mkeka: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // --- TEXT SETTINGS CONTROLS ---
  const handleSaveTexts = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionLoading(true);
    try {
      await setDoc(doc(db, 'settings', 'global'), globalConfig);
      triggerAlert('success', "Mandishi yote ya mfumo yamesajiliwa na kusasishwa kikamilifu! ✨");
    } catch (err: any) {
      triggerAlert('err', "Imeshindwa kuhifadhi mandishi: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  // --- DEPOSIT APPROVAL CONTROLS ---
  const handleApproveDeposit = async (dep: any) => {
    if (!window.confirm(`Je, una uhakika unataka KUTHIBITISHA malipo ya TZS ${dep.amount.toLocaleString()} kutoka kwa ${dep.username}? Salio lake litaongezwa kiotomatiki.`)) return;
    setActionLoading(true);
    try {
      // 1. Update the deposit status to 'approved'
      await updateDoc(doc(db, 'deposits', dep.id), {
        status: 'approved'
      });

      // 2. Increment user's balance
      await updateDoc(doc(db, 'users', dep.userId), {
        balance: increment(dep.amount)
      });

      // 3. Create activity log
      const logId = 'log-dep-approve-' + Math.random().toString(36).substring(2, 10);
      await setDoc(doc(db, 'activity_logs', logId), {
        id: logId,
        userId: dep.userId,
        username: dep.username,
        type: 'deposit_approved',
        amount: dep.amount,
        message: `Ombi la kuweka pesa la TZS ${dep.amount.toLocaleString()} la mtumiaji ${dep.username} limeidhinishwa na Admin. Salio limeongezeka.`,
        createdAt: new Date().toISOString()
      });

      // 4. Create notification
      const notifyId = 'notif-dep-approve-' + Math.random().toString(36).substring(2, 10);
      await setDoc(doc(db, 'notifications', notifyId), {
        id: notifyId,
        userId: dep.userId,
        title: 'Malipo Yamethibitishwa! ✅',
        message: `Ombi lako la kuweka TZS ${dep.amount.toLocaleString()} kupitia ${dep.paymentMethod} (ID ya Mwamala: ${dep.transactionId}) limeidhinishwa. Salio lako jipya limeongezeka!`,
        type: 'deposit',
        read: false,
        createdAt: new Date().toISOString()
      });

      triggerAlert('success', `Malipo ya TZS ${dep.amount.toLocaleString()} kwa mteja ${dep.username} yamethibitishwa na salio lake limeongezwa!`);
      onRefreshProfile();
    } catch (err: any) {
      triggerAlert('err', "Imeshindwa kuthibitisha: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleRejectDeposit = async (dep: any) => {
    if (!window.confirm(`Je, una uhakika unataka KATAA malipo ya TZS ${dep.amount.toLocaleString()} kutoka kwa ${dep.username}?`)) return;
    setActionLoading(true);
    try {
      // 1. Update the deposit status to 'rejected'
      await updateDoc(doc(db, 'deposits', dep.id), {
        status: 'rejected'
      });

      // 2. Create activity log
      const logId = 'log-dep-reject-' + Math.random().toString(36).substring(2, 10);
      await setDoc(doc(db, 'activity_logs', logId), {
        id: logId,
        userId: dep.userId,
        username: dep.username,
        type: 'deposit_rejected',
        amount: dep.amount,
        message: `Ombi la kuweka pesa la TZS ${dep.amount.toLocaleString()} la mtumiaji ${dep.username} limekataliwa na Admin.`,
        createdAt: new Date().toISOString()
      });

      // 3. Create notification
      const notifyId = 'notif-dep-reject-' + Math.random().toString(36).substring(2, 10);
      await setDoc(doc(db, 'notifications', notifyId), {
        id: notifyId,
        userId: dep.userId,
        title: 'Malipo Yamekataliwa ❌',
        message: `Ombi lako la kuweka TZS ${dep.amount.toLocaleString()} kupitia ${dep.paymentMethod} (ID: ${dep.transactionId}) limekataliwa na Admin baada ya uhakiki. Tafadhali wasiliana na huduma kwa wateja kwa msaada zaidi.`,
        type: 'deposit',
        read: false,
        createdAt: new Date().toISOString()
      });

      triggerAlert('success', `Ombi la malipo la ${dep.username} limekataliwa kikamilifu.`);
    } catch (err: any) {
      triggerAlert('err', "Imeshindwa kukataa: " + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const filteredUsers = users.filter((u) => {
    const q = userSearch.toLowerCase();
    return (
      (u.username || '').toLowerCase().includes(q) ||
      (u.email || '').toLowerCase().includes(q) ||
      (u.phoneNumber || '').toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6 font-sans">
      
      {/* Admin Title Banner */}
      <div className="bg-gradient-to-r from-red-500/10 via-black to-transparent border border-red-500/20 p-5 rounded-3xl flex justify-between items-center">
        <div>
          <span className="text-[10px] text-red-500 font-mono font-black uppercase tracking-widest block bg-red-500/10 border border-red-500/20 px-2 py-0.5 rounded-md w-max mb-1.5">SAPC PANEL</span>
          <h2 className="text-lg font-black text-white uppercase tracking-tight flex items-center gap-1.5 font-mono">
            🛡️ Admin Control Panel
          </h2>
          <p className="text-[10.5px] text-white/50 font-mono mt-0.5">
            Simamia watumiaji, weka mikeka ya premium kiotomatiki, na hariri taarifa zote.
          </p>
        </div>
        
        <div className="flex items-center gap-1 bg-red-500/10 p-2.5 rounded-full text-red-400">
          <Shield className="w-5 h-5 shrink-0" />
        </div>
      </div>

      {/* Admin Statistics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Card 1: Users */}
        <div className="bg-[#0F1116] border border-white/10 p-4 rounded-2xl flex items-center gap-3">
          <div className="p-3 bg-blue-500/10 text-blue-400 rounded-xl">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] text-white/40 uppercase font-mono">Watumiaji Wote</span>
            <span className="text-sm font-black text-white font-mono">{users.length}</span>
          </div>
        </div>

        {/* Card 2: Active Slips */}
        <div className="bg-[#0F1116] border border-white/10 p-4 rounded-2xl flex items-center gap-3">
          <div className="p-3 bg-red-500/10 text-red-400 rounded-xl">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] text-white/40 uppercase font-mono">Mikeka ya Leo</span>
            <span className="text-sm font-black text-white font-mono">
              {slips.filter(s => s.status === 'active' || !s.status).length} <span className="text-[10px] font-normal text-white/50">Active</span>
            </span>
          </div>
        </div>

        {/* Card 3: Pending Deposits */}
        <div className="bg-[#0F1116] border border-white/10 p-4 rounded-2xl flex items-center gap-3 relative overflow-hidden">
          {deposits.filter(d => d.status === 'pending').length > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-orange-500 rounded-full animate-ping" />
          )}
          <div className="p-3 bg-orange-500/10 text-orange-400 rounded-xl">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] text-white/40 uppercase font-mono">Maombi ya Pesa</span>
            <span className="text-sm font-black text-white font-mono flex items-center gap-1.5">
              {deposits.filter(d => d.status === 'pending').length}
              {deposits.filter(d => d.status === 'pending').length > 0 && (
                <span className="px-1.5 py-0.5 bg-orange-500/15 text-orange-400 border border-orange-500/20 rounded text-[8px] font-bold animate-pulse font-mono">PENDING</span>
              )}
            </span>
          </div>
        </div>

        {/* Card 4: Revenue / Deposits */}
        <div className="bg-[#0F1116] border border-white/10 p-4 rounded-2xl flex items-center gap-3">
          <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <span className="block text-[10px] text-white/40 uppercase font-mono">Jumla ya Mapato</span>
            <span className="text-xs font-black text-emerald-400 font-mono">
              TZS {deposits.filter(d => d.status === 'approved').reduce((acc, curr) => acc + (curr.amount || 0), 0).toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {actionLoading && (
        <div className="p-3.5 bg-red-500/10 border border-red-500/25 rounded-2xl flex items-center justify-center gap-2 text-red-400 font-mono text-[11px] animate-pulse">
          <RefreshCw className="w-4 h-4 animate-spin" />
          <span>Inaprosesa, tafadhali subiri kidogo...</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded-2xl flex gap-1.5 font-mono text-[11px]">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 bg-red-500/10 border border-red-500/20 text-red-400 rounded-2xl flex gap-1.5 font-mono text-[11px]">
          <AlertTriangle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Admin Subtabs Selector Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-1 bg-black/50 p-1.5 rounded-2xl border border-white/5 text-[9.5px] font-bold uppercase tracking-wider font-mono">
        <button
          onClick={() => setAdminTab('users')}
          className={`py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
            adminTab === 'users' ? 'bg-red-500 text-white' : 'text-white/60 hover:text-white'
          }`}
        >
          <Users className="w-3.5 h-3.5" /> Wasimamie Users ({users.length})
        </button>
        <button
          onClick={() => setAdminTab('tps')}
          className={`py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
            adminTab === 'tps' ? 'bg-red-500 text-white' : 'text-white/60 hover:text-white'
          }`}
        >
          <Zap className="w-3.5 h-3.5" /> Weka Premium Slips ({slips.length})
        </button>
        <button
          onClick={() => setAdminTab('deposits')}
          className={`py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 relative ${
            adminTab === 'deposits' ? 'bg-red-500 text-white' : 'text-white/60 hover:text-white'
          }`}
        >
          <CircleDollarSign className="w-3.5 h-3.5" /> Thibitisha Pesa ({deposits.filter(d => d.status === 'pending').length})
          {deposits.filter(d => d.status === 'pending').length > 0 && (
            <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-orange-500 rounded-full animate-pulse" />
          )}
        </button>
        <button
          onClick={() => setAdminTab('texts')}
          className={`py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
            adminTab === 'texts' ? 'bg-red-500 text-white' : 'text-white/60 hover:text-white'
          }`}
        >
          <Edit2 className="w-3.5 h-3.5" /> Hariri Mandishi
        </button>
        <button
          onClick={() => setAdminTab('db')}
          className={`py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1 ${
            adminTab === 'db' ? 'bg-red-500 text-white' : 'text-white/60 hover:text-white'
          }`}
        >
          <Database className="w-3.5 h-3.5" /> Supabase DB
        </button>
      </div>

      {/* VIEW PANEL TAB 1: USERS LIST & INLINE EDITING */}
      {adminTab === 'users' && (
        <div className="space-y-4">
          <div className="flex bg-[#0F1116] border border-white/10 rounded-2xl px-3 py-1.5 items-center gap-2">
            <Search className="w-4 h-4 text-white/40" />
            <input
              type="text"
              value={userSearch}
              onChange={(e) => setUserSearch(e.target.value)}
              placeholder="Tafuta mtumiaji kwa Jina, Email au Namba..."
              className="bg-transparent text-white text-xs py-1.5 focus:outline-none w-full font-mono"
            />
          </div>

          <div className="bg-[#0F1116] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-4 border-b border-white/5 flex justify-between items-center">
              <h3 className="text-xs font-black text-white uppercase tracking-wider font-mono flex items-center gap-1.5">
                👥 Orodha ya Watumiaji wa Mfumo ({filteredUsers.length})
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-[11px] font-mono whitespace-nowrap">
                <thead>
                  <tr className="bg-black/40 border-b border-white/5 text-white/45">
                    <th className="p-3 font-semibold uppercase">Mtumiaji</th>
                    <th className="p-3 font-semibold uppercase">Mawasiliano</th>
                    <th className="p-3 font-semibold uppercase text-right">Salio (TZS)</th>
                    <th className="p-3 font-semibold uppercase text-center">Kiwango</th>
                    <th className="p-3 font-semibold uppercase text-center">Hali (Status)</th>
                    <th className="p-3 font-semibold uppercase text-center">Vitendo</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filteredUsers.map((u) => {
                    const isEditing = editingUserId === u.uid;
                    return (
                      <tr key={u.uid} className="hover:bg-white/[0.02]">
                        <td className="p-3">
                          <p className="font-bold text-white text-xs">{u.username || "Noname User"}</p>
                          <p className="text-[10px] text-white/40 shrink-0">{u.uid.substring(0, 8)}...</p>
                        </td>
                        <td className="p-3">
                          <p className="text-white/80">{u.email}</p>
                          <p className="text-[10px] text-orange-400 font-semibold">{u.phoneNumber || "No Phone"}</p>
                        </td>
                        <td className="p-3 text-right">
                          {isEditing ? (
                            <input
                              type="number"
                              value={editBalance}
                              onChange={(e) => setEditBalance(e.target.value)}
                              className="w-24 bg-black border border-white/20 text-white text-[11px] px-1 py-0.5 rounded text-right focus:outline-none"
                            />
                          ) : (
                            <span className="font-bold text-emerald-400">TZS {(u.balance || 0).toLocaleString()}</span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          {isEditing ? (
                            <input
                              type="number"
                              value={editLevel}
                              onChange={(e) => setEditLevel(e.target.value)}
                              className="w-12 bg-black border border-white/20 text-white text-[11px] px-1 py-0.5 rounded text-center focus:outline-none"
                            />
                          ) : (
                            <span className="px-2 py-0.5 bg-orange-500/10 text-orange-400 border border-orange-500/20 rounded font-black">Kiwango {u.level || 0} VIP</span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          {isEditing ? (
                            <select
                              value={editStatus}
                              onChange={(e) => setEditStatus(e.target.value as any)}
                              className="bg-black border border-white/20 text-white text-[10px] rounded px-1.5 py-0.5 focus:outline-none"
                            >
                              <option value="active">Active</option>
                              <option value="suspended">Suspended</option>
                            </select>
                          ) : (
                            <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                              ((u as any).status || 'active') === 'active' 
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                                : 'bg-red-500/10 text-red-400 border border-red-500/20'
                            }`}>
                              {(u as any).status || 'active'}
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          {isEditing ? (
                            <div className="flex gap-1.5 justify-center">
                              <button
                                onClick={() => handleSaveUser(u.uid)}
                                className="bg-emerald-500 hover:bg-emerald-450 text-black px-2 py-1 rounded text-[10px] font-black uppercase flex items-center gap-0.5 cursor-pointer"
                              >
                                <Save className="w-3 h-3" /> Save
                              </button>
                              <button
                                onClick={() => setEditingUserId(null)}
                                className="bg-white/10 hover:bg-white/20 text-white px-2 py-1 rounded text-[10px] uppercase cursor-pointer"
                              >
                                Cancel
                              </button>
                            </div>
                          ) : (
                            <div className="flex gap-1.5 justify-center">
                              <button
                                onClick={() => handleStartEditUser(u)}
                                className="bg-white/5 hover:bg-white/10 text-white/80 p-1.5 rounded-lg border border-white/10 cursor-pointer"
                                title="Edit User Account"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteUser(u.uid)}
                                className="bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-black p-1.5 rounded-lg border border-red-500/20 cursor-pointer"
                                title="Delete User"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}

                  {filteredUsers.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-white/40 font-mono">
                        Nishati! Hakuna mtumiaji aliyejitokeza kwa neno hilo la utafutaji.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW PANEL TAB 4: DEPOSIT APPROVAL MANAGEMENT */}
      {adminTab === 'deposits' && (
        <div className="space-y-4 font-sans text-xs">
          {/* Filtering and search row */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-[#0F1116] border border-white/10 p-4 rounded-2xl">
            {/* Search Input */}
            <div className="flex bg-black/40 border border-white/10 rounded-xl px-3 py-2 items-center gap-2">
              <Search className="w-4 h-4 text-white/45 shrink-0" />
              <input
                type="text"
                placeholder="Tafuta kwa Mtumiaji au Transaction ID..."
                value={depositSearch}
                onChange={(e) => setDepositSearch(e.target.value)}
                className="bg-transparent text-white focus:outline-none w-full text-xs font-mono"
              />
            </div>

            {/* Filter buttons */}
            <div className="flex gap-1 bg-black/50 p-1 rounded-xl border border-white/5 md:col-span-2 overflow-x-auto">
              {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => {
                const count = status === 'all' 
                  ? deposits.length 
                  : deposits.filter(d => d.status === status).length;
                return (
                  <button
                    key={status}
                    onClick={() => setDepositStatusFilter(status)}
                    className={`flex-1 py-1 px-2.5 rounded-lg font-mono text-[10px] uppercase font-black tracking-wider transition-all cursor-pointer whitespace-nowrap ${
                      depositStatusFilter === status
                        ? 'bg-red-500 text-white'
                        : 'text-white/40 hover:text-white/80'
                    }`}
                  >
                    {status === 'all' && `ZOTE (${count})`}
                    {status === 'pending' && `ZINAZOSUBIRI (${count})`}
                    {status === 'approved' && `ZILIZOTHIBITISHWA (${count})`}
                    {status === 'rejected' && `ZILIZOKATALIWA (${count})`}
                  </button>
                );
              })}
            </div>
          </div>

          {/* List of deposits */}
          <div className="bg-[#0F1116] border border-white/10 rounded-3xl overflow-hidden shadow-xl">
            <div className="p-4 border-b border-white/10 flex justify-between items-center">
              <div>
                <h3 className="font-mono text-xs font-black text-white uppercase">Orodha ya Maombi ya Malipo</h3>
                <p className="text-[10px] text-white/40 font-mono">Bofya kuthitibisha salio au kukataa ombi la muamala.</p>
              </div>
              <span className="text-[10px] bg-white/5 border border-white/10 px-2.5 py-1 rounded-full font-mono font-bold text-white">
                Yamepatikana: {
                  deposits.filter(d => {
                    const matchesSearch = 
                      (d.username || '').toLowerCase().includes(depositSearch.toLowerCase()) ||
                      (d.transactionId || '').toLowerCase().includes(depositSearch.toLowerCase()) ||
                      (d.phone || '').toLowerCase().includes(depositSearch.toLowerCase());
                    const matchesStatus = depositStatusFilter === 'all' || d.status === depositStatusFilter;
                    return matchesSearch && matchesStatus;
                  }).length
                }
              </span>
            </div>

            <div className="divide-y divide-white/5 max-h-[600px] overflow-y-auto">
              {deposits.filter(d => {
                const matchesSearch = 
                  (d.username || '').toLowerCase().includes(depositSearch.toLowerCase()) ||
                  (d.transactionId || '').toLowerCase().includes(depositSearch.toLowerCase()) ||
                  (d.phone || '').toLowerCase().includes(depositSearch.toLowerCase());
                const matchesStatus = depositStatusFilter === 'all' || d.status === depositStatusFilter;
                return matchesSearch && matchesStatus;
              }).length === 0 ? (
                <div className="p-8 text-center text-white/40 font-mono">
                  Hakuna kumbukumbu za kuweka malipo zilizopatikana zenye vigezo hivi bado.
                </div>
              ) : (
                deposits.filter(d => {
                  const matchesSearch = 
                    (d.username || '').toLowerCase().includes(depositSearch.toLowerCase()) ||
                    (d.transactionId || '').toLowerCase().includes(depositSearch.toLowerCase()) ||
                    (d.phone || '').toLowerCase().includes(depositSearch.toLowerCase());
                  const matchesStatus = depositStatusFilter === 'all' || d.status === depositStatusFilter;
                  return matchesSearch && matchesStatus;
                }).map((dep) => (
                  <div key={dep.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 bg-black/15 hover:bg-black/25 transition-all">
                    {/* User & Txn Details */}
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-white">{dep.username}</span>
                        <span className="text-[9px] text-white/30 font-mono">ID: {dep.userId?.substring(0, 8)}...</span>
                        
                        {/* Status Badge */}
                        {dep.status === 'pending' && (
                          <span className="text-[8px] font-black tracking-widest text-orange-400 bg-orange-500/10 border border-orange-500/20 px-2 py-0.5 rounded uppercase font-mono animate-pulse">Pending ⏳</span>
                        )}
                        {dep.status === 'approved' && (
                          <span className="text-[8px] font-black tracking-widest text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded uppercase font-mono">Approved ✅</span>
                        )}
                        {dep.status === 'rejected' && (
                          <span className="text-[8px] font-black tracking-widest text-red-400 bg-red-500/10 border border-red-500/20 px-2 py-0.5 rounded uppercase font-mono">Rejected ❌</span>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-[10.5px] font-mono text-white/50">
                        <p>Njia ya Malipo: <span className="text-white font-sans">{dep.paymentMethod}</span></p>
                        <p className="flex items-center gap-1">
                          Namba: <span className="text-white">{dep.phone}</span>
                          {dep.phone && dep.phone !== 'PESAPAL_IFRAME' && (
                            <button 
                              onClick={() => {
                                navigator.clipboard.writeText(dep.phone);
                                alert("Imenakiliwa Namba ya Simu: " + dep.phone);
                              }}
                              className="text-orange-400 hover:text-orange-300"
                            >
                              <Copy className="w-3 h-3" />
                            </button>
                          )}
                        </p>
                        <p className="flex items-center gap-1 col-span-2">
                          Msimbo wa Operator: <span className="text-orange-400 font-bold tracking-wider">{dep.transactionId}</span>
                          <button 
                            onClick={() => {
                              navigator.clipboard.writeText(dep.transactionId);
                              alert("Imenakiliwa ID ya Muamala: " + dep.transactionId);
                            }}
                            className="text-white/40 hover:text-white"
                            title="Copy Transaction ID"
                          >
                            <Copy className="w-3 h-3" />
                          </button>
                        </p>
                        <p className="col-span-2 text-[9px] text-white/30">
                          Imewasilishwa: {new Date(dep.createdAt).toLocaleString('sw-TZ', { timeZone: 'Africa/Dar_es_Salaam' })}
                        </p>
                      </div>
                    </div>

                    {/* Amount & Actions */}
                    <div className="flex items-center justify-between md:justify-end gap-6 border-t md:border-t-0 border-white/5 pt-3 md:pt-0 shrink-0">
                      <div className="text-left md:text-right">
                        <p className="text-[9px] text-white/40 font-mono uppercase font-bold">Kiasi Kilichotajwa</p>
                        <p className="text-sm font-black text-emerald-400 font-mono">+{Number(dep.amount || 0).toLocaleString()} TZS</p>
                      </div>

                      {dep.status === 'pending' && (
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleRejectDeposit(dep)}
                            className="px-3 py-2 bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-black font-mono font-black uppercase text-[10px] rounded-xl border border-red-500/20 transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <XCircle className="w-3.5 h-3.5" /> Kataa
                          </button>
                          <button
                            onClick={() => handleApproveDeposit(dep)}
                            className="px-3 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-mono font-black uppercase text-[10px] rounded-xl transition-all flex items-center gap-1 cursor-pointer"
                          >
                            <Check className="w-3.5 h-3.5" /> Thibitisha
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* VIEW PANEL TAB 2: SETUP PREMIUM TIPS (TPS) */}
      {adminTab === 'tps' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {editingSlipId ? (
            /* Form EDIT Premium Slips (Active Slip Editor) */
            <form onSubmit={handleSaveSlipEdits} className="bg-[#0F1116] border border-blue-500/30 p-5 rounded-2xl space-y-4 text-left relative">
              <span className="absolute top-4 right-4 text-[9px] bg-blue-500/15 text-blue-400 border border-blue-500/20 rounded px-1.5 py-0.5 font-mono font-bold uppercase animate-pulse">MODE YA MAHARIRI</span>
              <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono flex items-center gap-1.5 pb-2 border-b border-white/5">
                ✏️ Hariri Premium Slip
              </h3>

              <div className="grid grid-cols-2 gap-3 font-mono text-[11px]">
                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black">Bookmaker</label>
                  <select
                    value={editSlipBookmaker}
                    onChange={(e) => setEditSlipBookmaker(e.target.value as any)}
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                  >
                    <option value="SportyBet">SportyBet</option>
                    <option value="BetPawa">BetPawa</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black">Bei/Cost (TZS)</label>
                  <input
                    type="number"
                    value={editSlipCost}
                    onChange={(e) => setEditSlipCost(e.target.value)}
                    placeholder="Mf. 2000 au 5000"
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none font-bold"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black">Odds za Mchongo</label>
                  <input
                    type="text"
                    value={editSlipOdds}
                    onChange={(e) => setEditSlipOdds(e.target.value)}
                    placeholder="Mf. 14.50"
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black">Accuracy Ring</label>
                  <input
                    type="text"
                    value={editSlipAccuracy}
                    onChange={(e) => setEditSlipAccuracy(e.target.value)}
                    placeholder="e.g. 99% Sure"
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-emerald-400 uppercase font-black">Hali ya Mkeka (Tiki ✅)</label>
                  <select
                    value={editSlipStatus}
                    onChange={(e) => setEditSlipStatus(e.target.value as any)}
                    className="w-full bg-[#0A0A0C] border border-emerald-500/30 rounded-xl px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500 font-bold"
                  >
                    <option value="active">⏳ Active / Haijaisha</option>
                    <option value="won">✅ Won / Umetiki (Tiki)</option>
                    <option value="lost">❌ Lost / Umepoteza</option>
                  </select>
                </div>

                <div className="space-y-1 col-span-2">
                  <label className="text-[9px] text-white/40 uppercase font-black">Muda wa kuanza Mechi (muda kwenye masaa kuanzia sasa)</label>
                  <input
                    type="number"
                    value={editSlipHours}
                    onChange={(e) => setEditSlipHours(e.target.value)}
                    placeholder="K.m: 8 (itatafsiri kuwa masaa 8 ya countdown ya mechi)"
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black">Booking Code</label>
                  <input
                    type="text"
                    value={editSlipBookingCode}
                    onChange={(e) => setEditSlipBookingCode(e.target.value)}
                    placeholder="Ingiza Booking Code"
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none select-all font-black uppercase"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-[#FB923C] uppercase font-black">Stake ya Mkeka (Stack Amount)</label>
                  <input
                    type="number"
                    value={editSlipStake}
                    onChange={(e) => setEditSlipStake(e.target.value)}
                    placeholder="Mf. 10000 au 25000"
                    className="w-full bg-[#0A0A0C] border border-orange-500/20 rounded-xl px-2.5 py-1.5 text-white focus:outline-none select-all font-black"
                    required
                  />
                </div>
              </div>

              {/* Selector Operations: "kuweka majina ya timu ama kuweka book code" */}
              <div className="space-y-2.5 bg-black/45 p-3 rounded-xl border border-white/5 text-[11px] font-mono">
                <label className="text-[9.5px] text-[#FB923C] uppercase font-black flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5" /> Operesheni Kubwa za Mkeka huu:
                </label>

                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setEditSlipOperationMode('teams')}
                    className={`py-2 px-3 rounded-lg border text-[10px] font-bold uppercase transition flex items-center justify-center gap-1 cursor-pointer ${
                      editSlipOperationMode === 'teams' 
                        ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' 
                        : 'bg-black/20 text-white/40 border-white/5 hover:text-white'
                    }`}
                  >
                    <ToggleLeft className="w-4 h-4" /> A: Majina ya Timu (Matches)
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditSlipOperationMode('code_only')}
                    className={`py-2 px-3 rounded-lg border text-[10px] font-bold uppercase transition flex items-center justify-center gap-1 cursor-pointer ${
                      editSlipOperationMode === 'code_only' 
                        ? 'bg-orange-500/10 text-orange-400 border-orange-500/30' 
                        : 'bg-black/20 text-white/40 border-white/5 hover:text-white'
                    }`}
                  >
                    <FileCode className="w-4 h-4" /> B: Booking Code pekee
                  </button>
                </div>

                {/* OP A: Render MATCH CARD Creator if teams is selected */}
                {editSlipOperationMode === 'teams' ? (
                  <div className="space-y-2 pt-2 border-t border-white/5">
                    <p className="text-[9px] text-white/50">I. Ongeza orodha ya michezo (Matches) ya mkeka huu:</p>
                    
                    <div className="space-y-1.5 bg-black/40 p-2.5 rounded-lg border border-white/5">
                      <input
                        type="text"
                        value={editNewMatchName}
                        onChange={(e) => setEditNewMatchName(e.target.value)}
                        placeholder="Jina la mechi (Simba vs Yanga)"
                        className="w-full bg-[#0F1116] border border-white/5 rounded-lg px-2 py-1 text-white text-[10px]"
                      />
                      <div className="grid grid-cols-3 gap-2">
                        <input
                          type="text"
                          value={editNewMatchPrediction}
                          onChange={(e) => setEditNewMatchPrediction(e.target.value)}
                          placeholder="Utabiri (Home Win)"
                          className="bg-[#0F1116] border border-white/5 rounded-lg px-2 py-1 text-white text-[10px]"
                        />
                        <input
                          type="number"
                          step="0.01"
                          value={editNewMatchOdds}
                          onChange={(e) => setEditNewMatchOdds(e.target.value)}
                          placeholder="Odds"
                          className="bg-[#0F1116] border border-white/5 rounded-lg px-2 py-1 text-white text-[10px]"
                        />
                        <select
                          value={editNewMatchStatus}
                          onChange={(e) => setEditNewMatchStatus(e.target.value as any)}
                          className="bg-[#0F1116] border border-white/5 rounded-lg px-2.5 py-1 text-white text-[10px] focus:outline-none"
                        >
                          <option value="active">⏳ Active</option>
                          <option value="won">✅ Won</option>
                          <option value="lost">❌ Lost</option>
                        </select>
                      </div>
                      <button
                        type="button"
                        onClick={handleAddMatchToEditSlip}
                        className="w-full py-1.5 bg-blue-500 hover:bg-blue-400 text-black text-[9px] font-black uppercase rounded-md flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" /> Ongeza Kwenye Orodha
                      </button>
                    </div>

                    {/* List of current added matches */}
                    {editSlipGames.length > 0 ? (
                      <div className="space-y-1.5 max-h-[140px] overflow-y-auto pt-1">
                        {editSlipGames.map((m, i) => (
                          <div key={i} className="p-2 bg-white/[0.01] border border-white/5 rounded-lg flex justify-between items-center text-[10px]">
                            <div>
                              <p className="font-bold text-white">{m.match}</p>
                              <p className="text-orange-400 font-semibold text-[9.5px]">
                                Pred: {m.prediction} | Odds: {m.odds} | Hali: <span className="uppercase text-white">{m.status || 'active'}</span>
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleRemoveMatchFromEditSlip(i)}
                              className="text-red-400 hover:text-white cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-[9px] text-white/30 text-center py-2 italic">Hakuna mechi iliyoongezwa bado kwenye mkeka.</p>
                    )}
                  </div>
                ) : (
                  <div className="p-3 bg-[#0A0A0C] border border-white/5 rounded-lg space-y-1 text-center font-mono mt-2">
                    <p className="text-[10px] text-orange-400 font-bold">MODE B: BOOKING CODE ONLY </p>
                    <p className="text-[9.5px] text-white/50">Mteja akilipia ataona bookmaker na Booking Code pekee, bila orodha ya timu!</p>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  type="submit"
                  className="w-full py-3 bg-blue-600 hover:bg-blue-500 text-white font-black text-xs uppercase rounded-xl flex items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer shadow-lg shadow-blue-500/10"
                >
                  <Save className="w-4 h-4" /> Hifadhi Maboresho!
                </button>
                <button
                  type="button"
                  onClick={() => setEditingSlipId(null)}
                  className="w-full py-3 bg-white/10 hover:bg-white/20 text-white font-black text-xs uppercase rounded-xl flex items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer"
                >
                  Ghairi (Cancel)
                </button>
              </div>
            </form>
          ) : (
            /* Form POST Premium Slips (New Tip Creator) */
            <form onSubmit={handlePostPremiumSlip} className="bg-[#0F1116] border border-white/10 p-5 rounded-2xl space-y-4 text-left">
              <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono flex items-center gap-1.5 pb-2 border-b border-white/5">
                🚀 Weka Premium Slip (TPS/Prediction) Mpya
              </h3>

              <div className="grid grid-cols-2 gap-3 font-mono text-[11px]">
                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black">Bookmaker</label>
                  <select
                    value={bookmaker}
                    onChange={(e) => setBookmaker(e.target.value as any)}
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                  >
                    <option value="SportyBet">SportyBet</option>
                    <option value="BetPawa">BetPawa</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black">Bei/Cost (TZS)</label>
                  <input
                    type="number"
                    value={slipCost}
                    onChange={(e) => setSlipCost(e.target.value)}
                    placeholder="Mf. 2000 au 5000"
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black">Odds za Mchongo</label>
                  <input
                    type="text"
                    value={slipOdds}
                    onChange={(e) => setSlipOdds(e.target.value)}
                    placeholder="Mf. 14.50"
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black">Accuracy Ring</label>
                  <input
                    type="text"
                    value={accuracy}
                    onChange={(e) => setAccuracy(e.target.value)}
                    placeholder="e.g. 99% Sure"
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-emerald-400 uppercase font-black">Hali ya Mkeka (Tiki ✅)</label>
                  <select
                    value={slipStatus}
                    onChange={(e) => setSlipStatus(e.target.value as any)}
                    className="w-full bg-[#0A0A0C] border border-emerald-500/30 rounded-xl px-2.5 py-1.5 text-white focus:outline-none focus:border-emerald-500 font-bold"
                  >
                    <option value="active">⏳ Active / Haijaisha</option>
                    <option value="won">✅ Won / Umetiki (Tiki)</option>
                    <option value="lost">❌ Lost / Umepoteza</option>
                  </select>
                </div>

                <div className="space-y-1 col-span-2">
                  <label className="text-[9px] text-white/40 uppercase font-black">Muda wa kuanza Mechi (muda kwenye masaa kuanzia sasa)</label>
                  <input
                    type="number"
                    value={matchHoursInFuture}
                    onChange={(e) => setMatchHoursInFuture(e.target.value)}
                    placeholder="K.m: 8 (itatafsiri kuwa masaa 8 ya countdown ya mechi)"
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-white/40 uppercase font-black">Booking Code</label>
                  <input
                    type="text"
                    value={bookingCode}
                    onChange={(e) => setBookingCode(e.target.value)}
                    placeholder="Ingiza Booking Code"
                    className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-1.5 text-white focus:outline-none select-all font-black uppercase"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] text-[#FB923C] uppercase font-black">Stake ya Mkeka (Stack Amount)</label>
                  <input
                    type="number"
                    value={slipStake}
                    onChange={(e) => setSlipStake(e.target.value)}
                    placeholder="Mf. 10000"
                    className="w-full bg-[#0A0A0C] border border-orange-500/20 rounded-xl px-2.5 py-1.5 text-white focus:outline-none font-bold"
                    required
                  />
                </div>
              </div>

              {/* Selector Operations: "kuweka majina ya timu ama kuweka book code" */}
              <div className="space-y-2.5 bg-black/45 p-3 rounded-xl border border-white/5 text-[11px] font-mono">
                <label className="text-[9.5px] text-[#FB923C] uppercase font-black flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5" /> Operesheni Kubwa za Mkeka huu:
                </label>

                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setSlipOperationMode('teams')}
                    className={`py-2 px-3 rounded-lg border text-[10px] font-bold uppercase transition flex items-center justify-center gap-1 cursor-pointer ${
                      slipOperationMode === 'teams' 
                        ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' 
                        : 'bg-black/20 text-white/40 border-white/5 hover:text-white'
                    }`}
                  >
                    <ToggleLeft className="w-4 h-4" /> A: Majina ya Timu (Matches)
                  </button>
                  <button
                    type="button"
                    onClick={() => setSlipOperationMode('code_only')}
                    className={`py-2 px-3 rounded-lg border text-[10px] font-bold uppercase transition flex items-center justify-center gap-1 cursor-pointer ${
                      slipOperationMode === 'code_only' 
                        ? 'bg-orange-500/10 text-orange-400 border-orange-500/30' 
                        : 'bg-black/20 text-white/40 border-white/5 hover:text-white'
                    }`}
                  >
                    <FileCode className="w-4 h-4" /> B: Booking Code pekee
                  </button>
                </div>

                {/* OP A: Render MATCH CARD Creator if teams is selected */}
                {slipOperationMode === 'teams' ? (
                  <div className="space-y-2 pt-2 border-t border-white/5">
                    <p className="text-[9px] text-white/50">I. Ongeza orodha ya michezo (Matches) ya mkeka huu:</p>
                    
                    <div className="space-y-1.5 bg-black/40 p-2.5 rounded-lg border border-white/5">
                      <input
                        type="text"
                        value={newMatchName}
                        onChange={(e) => setNewMatchName(e.target.value)}
                        placeholder="Jina la mechi (Simba vs Yanga)"
                        className="w-full bg-[#0F1116] border border-white/5 rounded-lg px-2 py-1 text-white text-[10px]"
                      />
                      <div className="grid grid-cols-3 gap-2">
                        <input
                          type="text"
                          value={newMatchPrediction}
                          onChange={(e) => setNewMatchPrediction(e.target.value)}
                          placeholder="Utabiri (Home Win)"
                          className="bg-[#0F1116] border border-white/5 rounded-lg px-2 py-1 text-white text-[10px]"
                        />
                        <input
                          type="number"
                          step="0.01"
                          value={newMatchOdds}
                          onChange={(e) => setNewMatchOdds(e.target.value)}
                          placeholder="Odds"
                          className="bg-[#0F1116] border border-white/5 rounded-lg px-2 py-1 text-white text-[10px]"
                        />
                        <select
                          value={newMatchStatus}
                          onChange={(e) => setNewMatchStatus(e.target.value as any)}
                          className="bg-[#0F1116] border border-white/5 rounded-lg px-2.5 py-1 text-white text-[10px] focus:outline-none"
                        >
                          <option value="active">⏳ Active</option>
                          <option value="won">✅ Won</option>
                          <option value="lost">❌ Lost</option>
                        </select>
                      </div>
                      <button
                        type="button"
                        onClick={handleAddMatchToNewSlip}
                        className="w-full py-1.5 bg-blue-500 hover:bg-blue-400 text-black text-[9px] font-black uppercase rounded-md flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <Plus className="w-3 h-3" /> Ongeza Kwenye Orodha
                      </button>
                    </div>

                    {/* List of current added matches */}
                    {matches.length > 0 ? (
                      <div className="space-y-1.5 max-h-[140px] overflow-y-auto pt-1">
                        {matches.map((m, i) => (
                          <div key={i} className="p-2 bg-white/[0.01] border border-white/5 rounded-lg flex justify-between items-center text-[10px]">
                            <div>
                              <p className="font-bold text-white">{m.match}</p>
                              <p className="text-orange-400 font-semibold text-[9.5px]">
                                Pred: {m.prediction} | Odds: {m.odds} | Hali: <span className="uppercase text-white">{m.status || 'active'}</span>
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleRemoveMatchFromNewSlip(i)}
                              className="text-red-400 hover:text-white cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-[9px] text-white/30 text-center py-2 italic">Hakuna mechi iliyoongezwa bado kwenye mkeka.</p>
                    )}
                  </div>
                ) : (
                  <div className="p-3 bg-[#0A0A0C] border border-white/5 rounded-lg space-y-1 text-center font-mono mt-2">
                    <p className="text-[10px] text-orange-400 font-bold">MODE B: BOOKING CODE ONLY </p>
                    <p className="text-[9.5px] text-white/50">Mteja akilipia ataona bookmaker na Booking Code pekee, bila orodha ya timu!</p>
                  </div>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-red-500 hover:bg-red-400 text-white font-black text-xs uppercase rounded-xl flex items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer shadow-lg shadow-red-500/10"
              >
                <Zap className="w-4 h-4" /> Chapisha Premium Slip Tayari!
              </button>
            </form>
          )}

          {/* List of Active posted Slips in Real-time */}
          <div className="bg-[#0F1116] border border-white/10 p-5 rounded-2xl space-y-4 text-left h-max">
            <h3 className="text-xs font-black text-white uppercase tracking-widest font-mono flex items-center gap-1.5 pb-2 border-b border-white/5">
              🔥 Premium Slips Zinazoonekana Sasa ({slips.length})
            </h3>

            <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
              {slips.map((s) => (
                <div key={s.id} className="p-3.5 bg-black/40 border border-white/10 rounded-xl space-y-2 font-mono text-[11px] relative overflow-hidden">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-1.5">
                      <span className={`w-5 h-5 rounded flex items-center justify-center text-[9px] font-black text-white relative ${
                        s.bookmaker === 'SportyBet' ? 'bg-[#E31C24]' : 'bg-[#7BB31A]'
                      }`}>
                        {s.bookmaker === 'SportyBet' ? 'S' : 'bP'}
                        <span className="absolute -bottom-0.5 -right-0.5 bg-emerald-500 rounded-full p-px border border-black text-white shadow-sm">
                          <Check className="w-1 h-1 stroke-[4]" />
                        </span>
                      </span>
                      <p className="font-bold text-white uppercase flex items-center gap-1">
                        {s.bookmaker} Tip
                        <Check className="w-3 h-3 text-emerald-400 stroke-[4] bg-emerald-500/15 p-px rounded-full shrink-0" />
                      </p>
                      
                      {s.status === 'won' && (
                        <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 text-[8px] font-bold rounded-md uppercase tracking-wider border border-emerald-500/30 flex items-center gap-0.5 animate-pulse">
                          ✅ Tiki Umetiki
                        </span>
                      )}
                      {s.status === 'lost' && (
                        <span className="px-1.5 py-0.5 bg-red-500/20 text-red-400 text-[8px] font-bold rounded-md uppercase tracking-wider border border-red-500/30 flex items-center gap-0.5">
                          ❌ Lost
                        </span>
                      )}
                      {(!s.status || s.status === 'active') && (
                        <span className="px-1.5 py-0.5 bg-blue-500/20 text-blue-400 text-[8px] font-bold rounded-md uppercase tracking-wider border border-blue-500/30 flex items-center gap-0.5">
                          ⏳ Active
                        </span>
                      )}
                    </div>

                    <div className="flex gap-1.5">
                      <button
                        onClick={() => handleStartEditSlip(s)}
                        className="p-1 px-2 bg-blue-500/10 hover:bg-blue-500 text-blue-400 hover:text-black border border-blue-500/20 text-[9px] rounded-lg cursor-pointer flex items-center gap-0.5 font-bold"
                      >
                        <Edit2 className="w-3 h-3" /> Hariri
                      </button>
                      <button
                        onClick={() => handleDeleteSlip(s.id)}
                        className="p-1 px-2 bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-black border border-red-500/20 text-[9px] rounded-lg cursor-pointer flex items-center gap-0.5 font-bold"
                      >
                        <Trash2 className="w-3 h-3" /> Futa
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-1 px-2.5 py-1.5 bg-white/[0.02] rounded-lg text-center text-[10px]">
                    <div>
                      <span className="block text-[8px] text-white/30 uppercase">Bei/Cost</span>
                      <span className="text-orange-400 font-bold">TZS {s.cost.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] text-white/30 uppercase">Odds</span>
                      <span className="text-emerald-400 font-bold">{s.odds.toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] text-white/30 uppercase">Muda kwisha</span>
                      <span className="text-blue-400 font-bold">{(s.expiresInSecs / 3600).toFixed(1)} Masaa</span>
                    </div>
                  </div>

                  {/* Matches sub info */}
                  <div className="space-y-1.5 pt-1.5 border-t border-white/5">
                    <p className="text-[9px] text-[#FB923C] uppercase font-bold flex justify-between">
                      <span>Booking Code:</span> 
                      <span className="text-white select-all font-black">{s.bookingCode}</span>
                    </p>
                    
                    {s.games && s.games.length > 0 ? (
                      <div className="space-y-1 pl-1 border-l border-white/10">
                        {s.games.map((g, idx) => (
                          <div key={idx} className="flex justify-between text-[10px] text-white/60">
                            <span className="truncate max-w-[130px]">{g.match}</span>
                            <span className="text-[#00FF55]">{g.prediction} ({g.odds.toFixed(2)})</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-[9.5px] text-white/35 italic">Huu ni mkeka wa Booking Code pekee (Haujumuishi orodha ya mechi).</p>
                    )}
                  </div>
                </div>
              ))}

              {slips.length === 0 && (
                <div className="p-6 text-center text-white/40 border border-dashed border-white/10 rounded-xl">
                  Hakuna mikijarabu ya Premium kwa sasa. Tumia fomu ya kushoto kuunda mkeka wa kwanza!
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* VIEW PANEL TAB 3: APP TEXT SETTINGS */}
      {adminTab === 'texts' && (
        <form onSubmit={handleSaveTexts} className="bg-[#0F1116] border border-white/10 p-6 rounded-2xl space-y-4 text-left font-mono text-[11.5px]">
          <h3 className="text-xs font-black text-white uppercase tracking-widest flex items-center gap-1.5 pb-2 border-b border-white/5">
            ✏️ Mhariri wa Mandishi Yote ya Mfumo (UI System Translation Customizer)
          </h3>
          <p className="text-[10px] text-white/50 leading-relaxed">
            Sasisha mandishi yote unayoyaona kwenye dashboard ya mteja. Hakuna haja ya kurekebisha code; thibitisha hapa na yatabadilika papo hapo kwa wateja wote kiotomatiki!
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            
            <div className="space-y-1">
              <label className="text-[9px] text-[#FB923C] uppercase font-black">Karibu Welcome Title (Heading)</label>
              <input
                type="text"
                value={globalConfig.welcomeTitle || ''}
                onChange={(e) => setGlobalConfig({ ...globalConfig, welcomeTitle: e.target.value })}
                className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-[9px] text-[#FB923C] uppercase font-black">Jina la Mfumo (Provider / Shop Name)</label>
              <input
                type="text"
                value={globalConfig.providerName || ''}
                onChange={(e) => setGlobalConfig({ ...globalConfig, providerName: e.target.value })}
                className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none uppercase"
                required
              />
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="text-[9px] text-[#FB923C] uppercase font-black">Karibu Welcome Subtitle (Paragraph Description)</label>
              <textarea
                value={globalConfig.welcomeSubtitle || ''}
                onChange={(e) => setGlobalConfig({ ...globalConfig, welcomeSubtitle: e.target.value })}
                rows={2}
                className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-[9px] text-[#FB923C] uppercase font-black">Premium Slips Header Title</label>
              <input
                type="text"
                value={globalConfig.premiumHeader || ''}
                onChange={(e) => setGlobalConfig({ ...globalConfig, premiumHeader: e.target.value })}
                className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none"
                required
              />
            </div>

            <div className="space-y-1">
              <label className="text-[9px] text-[#FB923C] uppercase font-black">Premium Promo Banner Ad / Alert</label>
              <input
                type="text"
                value={globalConfig.premiumPromo || ''}
                onChange={(e) => setGlobalConfig({ ...globalConfig, premiumPromo: e.target.value })}
                className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none"
                required
              />
            </div>

            <div className="space-y-1 md:col-span-2">
              <label className="text-[9px] text-[#FB923C] uppercase font-black font-mono">Picha ya Maelekezo ya Malipo ya Viwango (Upgrade Payment Image URL)</label>
              <input
                type="text"
                value={globalConfig.levelPaymentImageUrl || ''}
                onChange={(e) => setGlobalConfig({ ...globalConfig, levelPaymentImageUrl: e.target.value })}
                placeholder="Mfano: https://site.com/payment_qr.jpg au link ya picha yoyote ya maelekezo ya malipo"
                className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-3 py-2 text-white focus:outline-none"
              />
            </div>

            <div className="p-4 bg-orange-500/5 rounded-2xl border border-orange-500/10 md:col-span-2 grid grid-cols-2 md:grid-cols-4 gap-3">
              <p className="col-span-full text-[9px] text-white/50 uppercase font-black">Namba za Wakusanya Manual (Backup info)</p>
              
              <div className="space-y-1">
                <label className="text-[8px] text-white/30 uppercase">M-Pesa</label>
                <input
                  type="text"
                  value={globalConfig.mPesaNumber || ''}
                  onChange={(e) => setGlobalConfig({ ...globalConfig, mPesaNumber: e.target.value })}
                  className="w-full bg-[#0A0A0C] border border-white/10 rounded-lg px-2 py-1 text-white focus:outline-none text-[10.5px]"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[8px] text-white/30 uppercase">Airtel Money</label>
                <input
                  type="text"
                  value={globalConfig.airtelNumber || ''}
                  onChange={(e) => setGlobalConfig({ ...globalConfig, airtelNumber: e.target.value })}
                  className="w-full bg-[#0A0A0C] border border-white/10 rounded-lg px-2 py-1 text-white focus:outline-none text-[10.5px]"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[8px] text-white/30 uppercase">Tigo Pesa</label>
                <input
                  type="text"
                  value={globalConfig.tigoNumber || ''}
                  onChange={(e) => setGlobalConfig({ ...globalConfig, tigoNumber: e.target.value })}
                  className="w-full bg-[#0A0A0C] border border-white/10 rounded-lg px-2 py-1 text-white focus:outline-none text-[10.5px]"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[8px] text-white/30 uppercase">HaloPesa</label>
                <input
                  type="text"
                  value={globalConfig.haloNumber || ''}
                  onChange={(e) => setGlobalConfig({ ...globalConfig, haloNumber: e.target.value })}
                  className="w-full bg-[#0A0A0C] border border-white/10 rounded-lg px-2 py-1 text-white focus:outline-none text-[10.5px]"
                />
              </div>
            </div>

            {/* Live Design Customizer Settings */}
            <div className="p-4 bg-orange-500/5 rounded-2xl border border-orange-500/10 md:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-3">
              <p className="col-span-full text-[9.5px] text-[#FB923C] uppercase font-black font-mono">🎨 Mwonekano, Rangi & Mpangilio wa Dashboard (Live Design Config)</p>
              
              <div className="space-y-1">
                <label className="text-[8px] text-white/40 uppercase font-black font-mono">Accent Theme (Rangi & Mwonekano)</label>
                <select
                  value={globalConfig.themeStyle || 'cosmic_orange'}
                  onChange={(e) => setGlobalConfig({ ...globalConfig, themeStyle: e.target.value })}
                  className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-2 text-white font-mono text-[11px] focus:outline-none focus:border-red-500"
                >
                  <option value="cosmic_orange">Amber Sunset Orange (Classic)</option>
                  <option value="charcoal_red">Electric Red Accent (Fierce)</option>
                  <option value="emerald_slate">Bright Emerald Green (Winner)</option>
                  <option value="golden_trophy">Golden Trophy VIP (Premium)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[8px] text-white/40 uppercase font-black font-mono">Card Layout (Mpangilio wa Gridi)</label>
                <select
                  value={globalConfig.slipsLayout || 'one_column'}
                  onChange={(e) => setGlobalConfig({ ...globalConfig, slipsLayout: e.target.value })}
                  className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-2 text-white font-mono text-[11px] focus:outline-none focus:border-red-500"
                >
                  <option value="one_column">Gridi Moja Kubwa (Single Column)</option>
                  <option value="two_columns">Gridi Ndogo Mbili (Two-Column Grid)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[8px] text-white/40 uppercase font-black font-mono">Slips Sorting (Upangaji wa Mikeka)</label>
                <select
                  value={globalConfig.slipsSorting || 'countdown'}
                  onChange={(e) => setGlobalConfig({ ...globalConfig, slipsSorting: e.target.value })}
                  className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-2 text-white font-mono text-[11px] focus:outline-none focus:border-red-500"
                >
                  <option value="countdown">Saa ya mechi kuanza (Soonest)</option>
                  <option value="odds_desc">Odds Kubwa Kwanza (Highest Odds)</option>
                  <option value="cost_asc">Bei Ndogo Kwanza (Lowest Cost)</option>
                  <option value="newest">Mikeka Mipya Kwanza (Newest)</option>
                </select>
              </div>

              <div className="space-y-1 md:col-span-1">
                <label className="text-[8px] text-white/40 uppercase font-black font-mono">Mwanga wa Background (White Theme Mode)</label>
                <select
                  value={globalConfig.whiteThemeMode || 'disabled'}
                  onChange={(e) => setGlobalConfig({ ...globalConfig, whiteThemeMode: e.target.value })}
                  className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-2.5 py-2 text-white font-mono text-[11px] focus:outline-none focus:border-red-500"
                >
                  <option value="disabled">Hapana / Dark Mode (Default)</option>
                  <option value="enabled">Ndio / White Theme Mode (Mwanga Mweupe)</option>
                </select>
              </div>

              <div className="space-y-1 md:col-span-2">
                <label className="text-[8px] text-white/40 uppercase font-black font-mono">Picha ya Logo (Logo Image URL Override)</label>
                <input
                  type="text"
                  value={globalConfig.logoUrl || ''}
                  onChange={(e) => setGlobalConfig({ ...globalConfig, logoUrl: e.target.value })}
                  placeholder="Mf. https://site.com/images/logo.png"
                  className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-3 py-1.5 text-white font-mono text-[11px] focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="space-y-1 md:col-span-3">
                <label className="text-[8px] text-white/40 uppercase font-black font-mono">Picha ya Background (Background Image URL Override)</label>
                <input
                  type="text"
                  value={globalConfig.bgImageUrl || ''}
                  onChange={(e) => setGlobalConfig({ ...globalConfig, bgImageUrl: e.target.value })}
                  placeholder="Mf. https://site.com/images/soccer-background.jpg"
                  className="w-full bg-[#0A0A0C] border border-white/10 rounded-xl px-3 py-1.5 text-white font-mono text-[11px] focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="col-span-full border-t border-white/5 pt-2 mt-1">
                <p className="text-[9px] text-[#FB923C] uppercase font-black font-mono mb-2">🎨 Rangi za Kipekee za Tabu & Muda wa Mechi (Custom Tab & Match Time Colors)</p>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  <div className="space-y-1">
                    <label className="text-[7.5px] text-white/40 uppercase font-mono">Tab Inayofanya Kazi Bg (Active Tab Bg)</label>
                    <input
                      type="text"
                      value={globalConfig.activeTabBgColor || ''}
                      onChange={(e) => setGlobalConfig({ ...globalConfig, activeTabBgColor: e.target.value })}
                      placeholder="e.g. #FB923C"
                      className="w-full bg-[#0A0A0C] border border-white/10 rounded-lg px-2 py-1 text-white text-[10px]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[7.5px] text-white/40 uppercase font-mono">Tab Inayofanya Kazi Maandishi (Active Tab Text)</label>
                    <input
                      type="text"
                      value={globalConfig.activeTabTextColor || ''}
                      onChange={(e) => setGlobalConfig({ ...globalConfig, activeTabTextColor: e.target.value })}
                      placeholder="e.g. #000000"
                      className="w-full bg-[#0A0A0C] border border-white/10 rounded-lg px-2 py-1 text-white text-[10px]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[7.5px] text-white/40 uppercase font-mono">Tab Nyingine Bg (Inactive Tab Bg)</label>
                    <input
                      type="text"
                      value={globalConfig.inactiveTabBgColor || ''}
                      onChange={(e) => setGlobalConfig({ ...globalConfig, inactiveTabBgColor: e.target.value })}
                      placeholder="e.g. transparent"
                      className="w-full bg-[#0A0A0C] border border-white/10 rounded-lg px-2 py-1 text-white text-[10px]"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[7.5px] text-white/40 uppercase font-mono">Tab Nyingine Maandishi (Inactive Tab Text)</label>
                    <input
                      type="text"
                      value={globalConfig.inactiveTabTextColor || ''}
                      onChange={(e) => setGlobalConfig({ ...globalConfig, inactiveTabTextColor: e.target.value })}
                      placeholder="e.g. #9CA3AF"
                      className="w-full bg-[#0A0A0C] border border-white/10 rounded-lg px-2 py-1 text-white text-[10px]"
                    />
                  </div>
                  <div className="space-y-1 col-span-2 md:col-span-1">
                    <label className="text-[7.5px] text-white/40 uppercase font-mono font-bold text-orange-400">Rangi ya Muda wa Mechi (Match Time Color)</label>
                    <input
                      type="text"
                      value={globalConfig.matchTimeColor || ''}
                      onChange={(e) => setGlobalConfig({ ...globalConfig, matchTimeColor: e.target.value })}
                      placeholder="e.g. #3B82F6"
                      className="w-full bg-[#0A0A0C] border border-white/10 rounded-lg px-2 py-1 text-white text-[10px]"
                    />
                  </div>
                </div>
              </div>
            </div>

          </div>

          <button
            type="submit"
            className="w-full py-3 bg-red-600 hover:bg-red-500 text-white font-black text-xs uppercase rounded-xl flex items-center justify-center gap-1 active:scale-95 transition-all cursor-pointer shadow-lg shadow-red-500/15"
          >
            <CheckCircle2 className="w-4 h-4" /> Hifadhi na Kuchapisha Mandishi Yote Mfumo Mzima Sasa!
          </button>
        </form>
      )}

      {/* VIEW PANEL TAB 5: SUPABASE DATABASE STATUS & SETUP */}
      {adminTab === 'db' && (
        <div className="space-y-6 text-left font-sans text-xs">
          {/* Header Card */}
          <div className="bg-[#0F1116] border border-white/10 p-5 rounded-3xl shadow-xl">
            <div className="flex items-start gap-3.5">
              <div className="p-2.5 bg-red-500/10 text-red-500 rounded-2xl border border-red-500/20 shrink-0">
                <Database className="w-5 h-5 animate-pulse" />
              </div>
              <div className="space-y-1">
                <h3 className="font-mono text-sm font-black text-white uppercase tracking-wider">Hali ya Supabase Cloud Database</h3>
                <p className="text-[10.5px] text-white/40 font-mono leading-relaxed">
                  Angalia kama programu imeunganishwa na hifadhi ya wingu ya Supabase au inatumia Local Storage.
                </p>
              </div>
            </div>

            {/* Connection status banner */}
            <div className="mt-4">
              {fallbackTables.size > 0 ? (
                <div className="bg-orange-500/10 border border-orange-500/20 p-4 rounded-2xl space-y-2">
                  <div className="flex items-center gap-2 text-orange-400 font-bold text-[11px] font-mono">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>⚠️ BAADHI YA MAJEDWALI YAPO KWENYE LOCAL STORAGE (FALLBACK ACTIVE)</span>
                  </div>
                  <p className="text-[10.5px] text-white/60 leading-relaxed font-sans">
                    Baadhi ya majedwali bado hayajaanzishwa kwenye akaunti yako ya Supabase, hivyo data inahifadhiwa kwenye Local Storage kuzuia usumbufu wa utendaji wa programu. Tafadhali fuata maelekezo ya <strong>SQL Setup</strong> hapa chini ili kumalizia unganisho.
                  </p>
                </div>
              ) : (
                <div className="bg-emerald-500/10 border border-emerald-500/20 p-4 rounded-2xl space-y-1">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-[11px] font-mono">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>✅ MAJEDWALI YOTE YAMEUNGANISHWA KIKAMILIFU NA SUPABASE!</span>
                  </div>
                  <p className="text-[10.5px] text-white/60 leading-relaxed font-sans">
                    Hongera! Programu yako inaongea moja kwa moja na seva ya Supabase. Hakuna data inayohifadhiwa kwenye browser ya ndani sasa; taarifa zote ziko salama kwenye wingu (Cloud)!
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Tables Status Grid */}
          <div className="bg-[#0F1116] border border-white/10 p-5 rounded-3xl shadow-xl space-y-3">
            <h4 className="font-mono text-xs font-black text-white uppercase tracking-widest pb-2 border-b border-white/5">
              Orodha ya Majedwali ya Mfumo & Hali Yake
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
              {[
                { name: 'users', label: 'Watumiaji (users)' },
                { name: 'betslips', label: 'Premium Slips (betslips)' },
                { name: 'deposits', label: 'Maombi ya Malipo (deposits)' },
                { name: 'withdrawals', label: 'Kutoa Pesa (withdrawals)' },
                { name: 'notifications', label: 'Taarifa/Notification (notifications)' },
                { name: 'system_settings', label: 'Mipangilio ya Mfumo (system_settings)' },
                { name: 'video_tasks', label: 'Video za Watch-to-Earn (video_tasks)' },
                { name: 'task_completions', label: 'Historia ya Kazi (task_completions)' },
                { name: 'activity_logs', label: 'Kumbukumbu za Mfumo (activity_logs)' },
                { name: 'predictions', label: 'AI Predictions (predictions)' },
              ].map((table) => {
                const isFallback = fallbackTables.has(table.name);
                return (
                  <div key={table.name} className="flex items-center justify-between p-2.5 bg-black/35 border border-white/5 rounded-xl">
                    <span className="font-mono text-white/70">{table.label}</span>
                    {isFallback ? (
                      <span className="text-[9px] font-mono text-orange-400 bg-orange-500/5 border border-orange-500/10 px-2 py-0.5 rounded">
                        Offline Fallback 📱
                      </span>
                    ) : (
                      <span className="text-[9px] font-mono text-emerald-400 bg-emerald-500/5 border border-emerald-500/10 px-2 py-0.5 rounded font-bold">
                        Supabase Cloud ☁️
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* SQL Setup Instructions */}
          <div className="bg-[#0F1116] border border-white/10 p-5 rounded-3xl shadow-xl space-y-4">
            <div className="space-y-1">
              <h4 className="font-mono text-xs font-black text-white uppercase tracking-widest flex items-center gap-1.5 pb-2 border-b border-white/5">
                <FileCode className="w-4 h-4 text-orange-400" /> Jinsi ya Kumalizia Kuunganisha Supabase:
              </h4>
              <p className="text-[10.5px] text-white/50 leading-relaxed pt-1.5 font-sans">
                Kama baadhi ya majedwali yanaonyesha <strong>Offline Fallback</strong>, inamaanisha bado hujaweka schema ya mradi kwenye Supabase yako. Fuata hatua hizi rahisi kuweka sasa:
              </p>
            </div>

            <ol className="list-decimal list-inside space-y-2 text-[11px] text-white/70 font-mono pl-1">
              <li>
                Bofya kitufe cha chini cha <strong className="text-orange-400">Copy SQL Schema Code</strong> ili kucopy msimbo mzima wa database.
              </li>
              <li>
                Ingia kwenye akaunti yako ya Supabase Dashboard kwa anwani hii: <a href="https://supabase.com/dashboard" target="_blank" rel="noreferrer" className="text-red-400 hover:underline">https://supabase.com/dashboard</a>.
              </li>
              <li>
                Fungua mradi wako wa: <strong className="text-white">vtyfduzrysbjrnoeqojk</strong>.
              </li>
              <li>
                Kwenye upande wa kushoto, bonyeza alama ya <strong className="text-white">SQL Editor</strong> (alama ya majedwali na kalamu <code>&gt;_</code>).
              </li>
              <li>
                Bonyeza <strong className="text-white">+ New Query</strong> kisha paste msimbo ulioucopy hapo.
              </li>
              <li>
                Bonyeza kitufe cha kijani cha <strong className="text-emerald-400 font-bold">Run</strong> upande wa chini kulia mwa ukurasa.
              </li>
              <li>
                Baada ya hapo, bofya kitufe cha <strong className="text-red-400">Futa Cache & Jaribu Upya</strong> hapa chini ili kulazimisha programu kuongea na Supabase sasa!
              </li>
            </ol>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2">
              {/* Copy SQL Button */}
              <button
                onClick={() => {
                  navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
                  setCopiedSql(true);
                  setTimeout(() => setCopiedSql(false), 2000);
                }}
                className={`w-full py-3 rounded-xl font-bold font-mono text-[11px] uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer border ${
                  copiedSql 
                    ? 'bg-emerald-500 border-emerald-400 text-black' 
                    : 'bg-orange-500/10 border-orange-500/20 hover:bg-orange-500 text-orange-400 hover:text-black'
                }`}
              >
                {copiedSql ? (
                  <>
                    <Check className="w-4 h-4" /> Imecopiwa Kwenye Clipboard! ✅
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" /> Copy SQL Schema Code
                  </>
                )}
              </button>

              {/* Reset Cache & Reload Button */}
              <button
                onClick={() => {
                  if (confirm("Je, una uhakika unataka kufuta Local Cache na kujaribu upya kuunganisha na Supabase? Programu itajireload.")) {
                    localStorage.clear();
                    window.location.reload();
                  }
                }}
                className="w-full py-3 bg-red-600 hover:bg-red-500 text-white font-bold font-mono text-[11px] uppercase rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-red-500/15 active:scale-95 transition-all"
              >
                <RefreshCw className="w-4 h-4" /> Futa Cache & Jaribu Upya
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
