import React, { useState, useEffect } from 'react';
import { db, doc, onSnapshot, collection } from '../supabase';
import { UserProfile } from '../types';
import { 
  ShieldCheck, Clock, BookOpen, Trophy, CheckCircle2, AlertCircle, Info, Check
} from 'lucide-react';
import { Betslip } from './Dashboard';

interface PredictionsProps {
  profile: UserProfile;
  onRefreshProfile: () => void;
}

export default function Predictions({ profile, onRefreshProfile }: PredictionsProps) {
  const [unlockedSlips, setUnlockedSlips] = useState<Betslip[]>([]);

  // Hardcoded premium seed slips matching the picture details exactly to re-populate the My Bets
  const slipsDatabase: Betslip[] = [
    {
      id: "slip_1",
      bookmaker: "SportyBet",
      provider: "SAPC TIPS",
      odds: 10.61,
      stake: 6000,
      expiresInSecs: 20537,
      accuracy: "High Accuracy",
      cost: 1500,
      bookingCode: "SB-TZ-834920",
      games: [
        { match: "Real Madrid vs AC Milan", prediction: "Home Win", odds: 1.51 },
        { match: "Liverpool vs Leverkusen", prediction: "Over 2.5 Goals", odds: 1.60 },
        { match: "Lille vs Juventus", prediction: "Both Teams Score (Yes)", odds: 1.85 },
        { match: "Sporting vs Man City", prediction: "Man City Win/Draw", odds: 1.25 },
        { match: "Celtic vs Leipzig", prediction: "Over 1.5 Goals", odds: 1.22 }
      ]
    },
    {
      id: "slip_2",
      bookmaker: "BetPawa",
      provider: "SAPC TIPS",
      odds: 11.88,
      stake: 6000,
      expiresInSecs: 20537,
      accuracy: "High Accuracy",
      cost: 1500,
      bookingCode: "BP-542129",
      games: [
        { match: "Man United vs PAOK", prediction: "Home Win & Over 1.5", odds: 1.45 },
        { match: "Lazio vs FC Porto", prediction: "Draw or Porto Win", odds: 1.55 },
        { match: "Galatasaray vs Tottenham", prediction: "Over 2.5 Goals", odds: 1.50 },
        { match: "Chelsea vs FC Noah", prediction: "Chelsea -1.5 Handicap", odds: 1.30 },
        { match: "Olympiacos vs Rangers", prediction: "Both Teams Score (Yes)", odds: 1.80 }
      ]
    },
    {
      id: "slip_3",
      bookmaker: "BetPawa",
      provider: "SAPC TIPS",
      odds: 105.00,
      stake: 7000,
      expiresInSecs: 107597,
      accuracy: "High Accuracy",
      cost: 3000,
      bookingCode: "BP-SURE-105",
      games: [
        { match: "Bologna vs Monaco", prediction: "Monaco Win", odds: 2.65 },
        { match: "Shakhtar vs Young Boys", prediction: "Draw", odds: 3.40 },
        { match: "Club Brugge vs Aston Villa", prediction: "Aston Villa Win", odds: 2.15 },
        { match: "Bayern vs Benfica", prediction: "Home Win & BTTS", odds: 2.50 },
        { match: "Inter Milan vs Arsenal", prediction: "Under 2.5 Goals", odds: 1.80 }
      ]
    }
  ];

  const [dbSlips, setDbSlips] = useState<Betslip[]>([]);
  const [unlockedIds, setUnlockedIds] = useState<string[]>([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'betslips'), (snap) => {
      if (!snap.empty) {
        setDbSlips(snap.docs.map(d => d.data() as Betslip));
      } else {
        setDbSlips([]);
      }
    }, () => {
      setDbSlips([]);
    });
    return () => unsub();
  }, []);

  // Sync unlockedIds on profile load or change
  useEffect(() => {
    const saved = localStorage.getItem(`unlocked_slips_${profile.uid}`);
    if (saved) {
      setUnlockedIds(JSON.parse(saved));
    } else {
      setUnlockedIds([]);
    }
  }, [profile.uid]);

  // Refresh and load unlocked slips on load
  useEffect(() => {
    const allSlips = [...dbSlips];
    slipsDatabase.forEach(staticSlip => {
      if (!allSlips.some(s => s.id === staticSlip.id)) {
        allSlips.push(staticSlip);
      }
    });

    const available = allSlips.filter(slip => unlockedIds.includes(slip.id));
    setUnlockedSlips(available);
  }, [profile.uid, profile.level, dbSlips, unlockedIds]);

  const handleRemoveUnlockedSlip = (slipId: string) => {
    if (window.confirm("Je, una uhakika unataka kufuta mkeka huu kwenye orodha yako ya 'My Bets'?")) {
      const updated = unlockedIds.filter(id => id !== slipId);
      setUnlockedIds(updated);
      localStorage.setItem(`unlocked_slips_${profile.uid}`, JSON.stringify(updated));
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Title Header */}
      <div className="p-4 bg-white/[0.03] border border-white/10 rounded-2xl space-y-1 glass">
        <h4 className="text-xs font-bold text-white uppercase tracking-wide font-mono flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-orange-400" /> VIP Mikeka Yangu ({unlockedSlips.length})
        </h4>
        <p className="text-[10px] text-white/50 leading-relaxed font-sans">
          Hapa unaona mikeka yote ya VIP ambayo umeshavalisha au kuifungua hivi sasa kutoka kwenye ukurasa wa nyumbani.
        </p>
      </div>

      {/* PART A: MY UNLOCKED BET SLIPS */}
      <div className="space-y-4 animate-fade-in">
        {unlockedSlips.length === 0 ? (
          <div className="text-center py-12 bg-white/[0.02] border border-white/10 rounded-3xl p-6 space-y-3 glass font-sans">
            <Trophy className="w-12 h-12 text-white/30 mx-auto" />
            <h3 className="text-sm font-bold text-white uppercase">Huna Slip Iliyofunguliwa!</h3>
            <p className="text-[11px] text-white/40 leading-relaxed max-w-xs mx-auto">
              Huoni mikeka yoyote hapa kwa sababu bado huja-unlock active slips kwenye ukurasa wa **Home**. Kiwango cha 1+ hufungua Bure!
            </p>
          </div>
        ) : (
          unlockedSlips.map((slip) => (
            <div key={slip.id} className="bg-[#0F1116] border border-emerald-500/30 rounded-[22px] p-5 space-y-4">
              
              {/* Slip Header Info */}
              <div className="flex justify-between items-start border-b border-white/5 pb-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 font-mono">
                    <span className="text-[10px] font-black tracking-widest text-[#FFFFFF]/30 uppercase bg-[#000000]/40 py-1 px-2.5 rounded-lg border border-white/5">
                      {slip.bookmaker || 'SportyBet'}
                    </span>
                    <span className="text-[8px] uppercase px-1.5 py-0.5 bg-emerald-500/10 text-emerald-400 font-bold rounded flex items-center gap-0.5 border border-emerald-500/15 animate-pulse">
                      <ShieldCheck className="w-2.5 h-2.5" /> UNLOCKED
                    </span>
                  </div>
                  <h3 className="text-lg font-black tracking-tight text-white font-mono mt-1">
                    {slip.odds.toFixed(2)} ODDS VIP SLIP
                  </h3>
                </div>

                <div className="text-right space-y-1 font-mono">
                  <span className="block text-[8px] text-white/30 uppercase tracking-widest">Dhamana (Booking Code)</span>
                  <span className="block text-sm font-black text-emerald-400 select-all tracking-wider bg-emerald-500/5 px-2.5 py-1 rounded-lg border border-emerald-500/10">
                    {slip.bookingCode}
                  </span>
                  <button
                    onClick={() => handleRemoveUnlockedSlip(slip.id)}
                    className="mt-1 px-2 py-0.5 bg-red-500/10 hover:bg-red-500 hover:text-black border border-red-500/20 text-red-400 text-[8px] font-bold rounded uppercase transition cursor-pointer"
                  >
                    Futa Mkeka ✕
                  </button>
                </div>
              </div>

              {/* Games breakdown lists */}
              <div className="space-y-3 font-sans">
                {slip.games.map((g, gi) => {
                  const gameStatus = g.status || 'active';
                  return (
                    <div 
                      key={gi} 
                      className={`flex justify-between items-center text-xs p-3 rounded-xl bg-[#000000]/40 border transition ${
                        gameStatus === 'won' 
                          ? 'border-emerald-500/30 bg-emerald-500/5' 
                          : gameStatus === 'lost' 
                            ? 'border-red-500/30 bg-red-500/5' 
                            : 'border-white/5'
                      }`}
                    >
                      <div className="space-y-1">
                        <span className="block font-black text-[#FFFFFF]/90 font-mono text-[11.5px] uppercase">{g.match}</span>
                        <div className="flex flex-wrap items-center gap-2 font-mono">
                          <span className="inline-flex items-center gap-1 text-[9px] text-white/40 uppercase font-bold tracking-tight">
                            <Clock className="w-2.5 h-2.5" /> Utabiri: <span className="text-orange-400">{g.prediction}</span>
                          </span>
                          
                          {/* Match Win/Loss status display ("zime Wini ama Los") */}
                          {gameStatus === 'won' && (
                            <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 text-[8px] font-black rounded uppercase tracking-wider border border-emerald-500/30">
                              ✅ Won / Umetiki
                            </span>
                          )}
                          {gameStatus === 'lost' && (
                            <span className="px-1.5 py-0.5 bg-red-500/20 text-red-400 text-[8px] font-black rounded uppercase tracking-wider border border-red-500/30">
                              ❌ Lost / Imepoteza
                            </span>
                          )}
                          {gameStatus === 'active' && (
                            <span className="px-1.5 py-0.5 bg-blue-500/10 text-blue-400 text-[8px] font-bold rounded uppercase tracking-wider border border-blue-500/20">
                              ⏳ Active / Pending
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right font-mono">
                        <span className="text-xs font-black text-white bg-white/5 px-2 py-0.5 rounded-md border border-white/10">
                          @{g.odds.toFixed(2)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>

            </div>
          ))
        )}
      </div>

    </div>
  );
}
