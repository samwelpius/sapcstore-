import React, { useState, useEffect } from 'react';
import { 
  db, 
  auth,
  doc, 
  setDoc,
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendPasswordResetEmail,
  signOut,
  getDocs,
  collection,
  onSnapshot
} from '../supabase';
import { UserProfile } from '../types';
import { Shield, Sparkles, AlertCircle, CheckCircle, Mail, Lock, User as UserIcon, Smartphone } from 'lucide-react';

interface AuthProps {
  onSuccess: (profile: UserProfile | null) => void;
}

export default function Auth({ onSuccess }: AuthProps) {
  const [globalConfig, setGlobalConfig] = useState<any>({
    providerName: "SAPC STORE"
  });

  useEffect(() => {
    const unsubGlobal = onSnapshot(doc(db, 'settings', 'global'), (snap) => {
      if (snap.exists()) {
        setGlobalConfig(snap.data());
      }
    });
    return () => unsubGlobal();
  }, []);

  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [forgotPassword, setForgotPassword] = useState(false);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Helper to generate a random referral code
  const generateReferralCode = () => {
    return 'SAPC' + Math.floor(100000 + Math.random() * 900000);
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      if (isLogin) {
        // Sign In
        const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
        // Success managed by listeners in App.tsx
      } else {
        // Sign Up
        if (!username.trim()) {
          throw new Error("Tafadhali jaza jina lako la mtumiaji (username)");
        }
        if (!phoneNumber.trim()) {
          throw new Error("Tafadhali weka namba yako ya simu ya m-pesa/tigo-pesa");
        }
        if (phoneNumber.trim().length < 9) {
          throw new Error("Namba ya simu sio sahihi. Lazima iwe na kuanzia tarakimu 9.");
        }
        if (password.length < 6) {
          throw new Error("Nywila lazima iwe na angalau herufi 6");
        }

        // Validate unique phone number
        const allUsersSnap = await getDocs(collection(db, 'users'));
        const isPhoneTaken = (allUsersSnap.docs || []).some(docItem => {
          const uProfile = docItem.data();
          const pNo = uProfile.phoneNumber || uProfile.device_info || '';
          return pNo.trim() === phoneNumber.trim();
        });

        if (isPhoneTaken) {
          throw new Error("Namba hii ya simu tayari imeshasajiliwa na akaunti nyingine!");
        }

        const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
        const user = userCredential.user;

        // Create standard profile in Firestore
        const newUserRef: UserProfile = {
          uid: user.uid,
          email: user.email || email,
          username: username.trim(),
          phoneNumber: phoneNumber.trim(),
          balance: 0,
          totalEarnings: 0,
          totalReferrals: 0,
          level: 0, // Free Level by default
          referralCode: generateReferralCode(),
          referredBy: referralCode.trim() || undefined,
          createdAt: new Date().toISOString(),
          role: (email.trim().toLowerCase() === 'djafloekemoda@gmail.com') ? 'admin' : 'user',
          status: 'active'
        };

        await setDoc(doc(db, 'users', user.uid), newUserRef);

        // Keep a persistent registration log
        const logId = 'log-reg-' + Math.random().toString(36).substring(2, 10);
        await setDoc(doc(db, 'activity_logs', logId), {
          id: logId,
          userId: user.uid,
          username: username.trim(),
          email: user.email || email.trim(),
          type: 'registration',
          message: `Mtumiaji mpya ${username.trim()} (${user.email || email.trim()}) amejisajili na namba ${phoneNumber.trim()}. Karibu sana! ✨`,
          createdAt: new Date().toISOString()
        });

        setSuccessMsg("Akaunti imeundwa kwa mafanikio! Sasa unaweza kuingia.");
        setIsLogin(true);
      }
    } catch (err: any) {
      console.error(err);
      let localErr = err.message;
      if (err.code === 'auth/wrong-password' || err.code === 'auth/user-not-found') {
        localErr = "Barua zilizofungwa au kiunganisho si sahihi. Jaribu tena.";
      } else if (err.code === 'auth/email-already-in-use') {
        localErr = "Barua pepe hii tayari inatumika na akaunti nyingine.";
      } else if (err.code === 'auth/invalid-email') {
        localErr = "Mfumo wa barua pepe haupo sahihi.";
      }
      setError(localErr);
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError("Tafadhali weka barua pepe yako ili kutuma kiungo cha upya.");
      return;
    }
    setLoading(true);
    setError(null);
    setSuccessMsg(null);

    try {
      await sendPasswordResetEmail(auth, email.trim());
      setSuccessMsg("Kiungo cha upya nywila kimetumwa kwenye barua pepe yako! Tafadhali angalia inbox.");
      setForgotPassword(false);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || "Imeshindwa kutuma barua pepe ya upya.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[92vh] px-4 py-8 bg-[#0A0A0C] text-white">
      <div className="w-full max-w-sm p-6 space-y-6 bg-white/[0.03] border border-white/10 rounded-2xl shadow-2xl glass accent-glow">
        
        {/* LOGO Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-tr from-orange-500 to-orange-300 text-black font-bold text-2xl tracking-tighter shadow-lg shadow-orange-500/20">
            {globalConfig.providerName ? globalConfig.providerName.trim().charAt(0).toUpperCase() : 'S'}
          </div>
          <h1 className="text-2xl font-black tracking-tight text-white uppercase sm:text-3xl">
            {globalConfig.providerName ? (
              <>
                {globalConfig.providerName.split(' ')[0]} <span className="text-orange-400">{globalConfig.providerName.split(' ').slice(1).join(' ') || 'TIPS'}</span>
              </>
            ) : (
              <>
                SAPC <span className="text-orange-400">STORE</span>
              </>
            )}
          </h1>
          <p className="text-xs text-white/40 font-mono">
            Tanzania No.1 Premium Investment & Football AI
          </p>
        </div>

        {error && (
          <div className="flex items-start p-3 text-sm rounded bg-red-500/10 border border-red-500/20 text-red-400 gap-2 font-mono">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {successMsg && (
          <div className="flex items-start p-3 text-sm rounded bg-orange-500/10 border border-orange-500/20 text-orange-400 gap-2 font-mono">
            <CheckCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {forgotPassword ? (
          // Forgot Password Form
          <form onSubmit={handleResetPassword} className="space-y-4">
            <div className="space-y-1">
              <label className="text-xs font-semibold text-white/60">Barua Pepe (Email)</label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="mfano@sapc.com"
                  className="w-full px-3 py-2 pl-9 bg-black/40 border border-white/10 rounded-lg text-sm focus:outline-none focus:border-orange-500 text-white font-mono"
                  required
                />
                <Mail className="absolute left-3 top-2.5 w-4 h-4 text-white/40" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2 bg-orange-500 hover:bg-orange-400 disabled:bg-white/5 text-black font-bold rounded-lg text-sm transition-all shadow-md accent-glow"
            >
              {loading ? "Inatuma..." : "Tuma Kiungo cha Nywila"}
            </button>

            <button
              type="button"
              onClick={() => {
                setForgotPassword(false);
                setError(null);
              }}
              className="w-full text-center text-xs text-white/40 hover:text-white transition-colors"
            >
              Rudi Kwenye Kuingia
            </button>
          </form>
        ) : (
          // Login & Register Form
          <form onSubmit={handleAuth} className="space-y-4">
            
            {!isLogin && (
              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-white/60">Jina la Mtumiaji (Username)</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="Jina la mtumiaji"
                      className="w-full px-3 py-2 pl-9 bg-black/40 border border-white/10 rounded-lg text-sm focus:outline-none focus:border-orange-500 text-white"
                      required={!isLogin}
                    />
                    <UserIcon className="absolute left-3 top-2.5 w-4 h-4 text-white/40" />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-white/60">Namba ya Simu (M-Pesa / Tigo Pesa / Airtel Money)</label>
                  <div className="relative">
                    <input
                      type="text"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="Mfano: 07xxxxxxxx"
                      className="w-full px-3 py-2 pl-9 bg-black/40 border border-white/10 rounded-lg text-sm focus:outline-none focus:border-orange-500 text-white font-mono"
                      required={!isLogin}
                    />
                    <Smartphone className="absolute left-3 top-2.5 w-4 h-4 text-white/40" />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-white/60">Kodi ya Mwalishi (Referral Code)</label>
                  <input
                    type="text"
                    value={referralCode}
                    onChange={(e) => setReferralCode(e.target.value)}
                    placeholder="SAPC123456"
                    className="w-full px-3 py-2 bg-black/40 border border-white/10 rounded-lg text-sm uppercase focus:outline-none focus:border-orange-500 text-white font-mono"
                  />
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-semibold text-white/60">Barua Pepe (Email)</label>
              <div className="relative">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="mfano@sapc.com"
                  className="w-full px-3 py-2 pl-9 bg-black/40 border border-white/10 rounded-lg text-sm focus:outline-none focus:border-orange-500 text-white font-mono"
                  required
                />
                <Mail className="absolute left-3 top-2.5 w-4 h-4 text-white/40" />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-white/60">Nywila (Password)</label>
                {isLogin && (
                  <button
                    type="button"
                    onClick={() => {
                      setForgotPassword(true);
                      setError(null);
                    }}
                    className="text-[10px] text-orange-400 hover:underline"
                  >
                    Umesahau?
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Nywila yako"
                  className="w-full px-3 py-2 pl-9 bg-black/40 border border-white/10 rounded-lg text-sm focus:outline-none focus:border-orange-500 text-white"
                  required
                />
                <Lock className="absolute left-3 top-2.5 w-4 h-4 text-white/40" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 hover:to-amber-400 disabled:from-white/5 disabled:to-white/5 text-black font-extrabold rounded-xl text-xs tracking-wider uppercase transition-all shadow-lg active:scale-98 cursor-pointer"
            >
              {loading ? "Tafadhali subiri..." : isLogin ? "INGIA AKAUNTINI ⚡" : "JISAJILI SASA ✨"}
            </button>



            {/* Switch Mode Toggle */}
            <div className="text-center font-medium pt-1">
              <button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setError(null);
                  setSuccessMsg(null);
                }}
                className="text-xs text-white/40 hover:text-orange-400 transition-colors"
              >
                {isLogin ? "Huna akaunti? Jisajili Sasa" : "Tayari unayo akaunti? Ingia hapa"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
