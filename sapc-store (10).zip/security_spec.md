# SAPC Store Security Specification

## 1. Data Invariants
1. **User Identity Invariant**: A user document must have a `uid` matching the authenticated user ID. Nobody can modify another user's balance, level, role, or referral counts.
2. **Admin Status Sanctity**: Users can NEVER promote themselves to `role: 'admin'`. Admin privileges are guarded by checking `role == 'admin'` of the existing record or a locked system store.
3. **Transaction Rigor**: Users cannot create arbitrary Approved deposits or approved withdrawals. These are pending by default and can only be approved by users with `role == 'admin'`.
4. **Task Reward Locking**: Completions must match standard daily limits per level (Level 1: 5 tasks, Level 2: 10 tasks, Level 3: 15 tasks, Level 4: 25 tasks). Users cannot log completed tasks for other users or claim unearned rewards.
5. **Immutable History**: Historical timestamps (`createdAt`) must be set to `request.time`. Once a record (deposit, withdrawal, completion) is set, structural columns like `userId` and `amount` are immutable.

## 2. The "Dirty Dozen" Payloads
These payloads attempt to breach the Zero-Trust security rules and must return `PERMISSION_DENIED`.

1. **Self-Promotion**: Non-admin user tries to write a profile with `role: "admin"`.
2. **Balance Spoofing**: User tries to update their own `balance` to `9999999`.
3. **Impersonated Read**: User `A` tries to read `users/user_B`.
4. **Direct Approved Deposit**: User tries to create `deposits` with `status: "approved"` directly.
5. **Deposit Hijack**: User `A` tries to update `deposits/dep_B` owned by user `B`.
6. **Withdrawal Fraud**: User tries to post a withdrawal request with a negative amount or an amount exceeding their balance.
7. **Direct Approved Withdrawal**: User tries to create `withdrawals` with `status: "approved"`.
8. **Completion Spoofing**: User tries to submit a task completion with a reward higher than their level allows.
9. **Fake Video Adding**: User tries to add a custom video URL and reward in `videos/` (only Admins can write `videos/`).
10. **System Settings Mutate**: User tries to edit `settings/central_configs` (only Admins can write settings).
11. **Referral Theft**: User tries to rewrite their `referredBy` or someone else's referral metrics.
12. **Future Timestamp Spoofing**: User submits a completion with a manually spoofed `createdAt` in the future.

## 3. Test Runner Specification (firestore.rules.test.ts)

All of these interactions will return `PERMISSION_DENIED` under a secure firestore.rules setup. Testing is run against the Firestore emulator or verified in rules logic:
- `users/{uid}`: Read allowed only if `request.auth.uid == uid` or is Admin. Write allowed only if `request.auth.uid == uid` and does not change role, balance, or referrals unless signed by an approved transactional batch or Admin.
- `deposits/{id}`: Create allowed if authenticated. Fields `userId` must equal `request.auth.uid` and `status` must be `pending`. Update only allowed if role is admin.
- `withdrawals/{id}`: Create allowed if authenticated. `userId` must be `request.auth.uid` and `status` must be `pending`. Update only allowed if admin.
- `videos/{id}`: Read allowed for all users. Write / Update only allowed if admin.
- `settings/{id}`: Read allowed for all users. Write only if admin.
