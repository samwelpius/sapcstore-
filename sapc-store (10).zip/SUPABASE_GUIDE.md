# SAPC STORE - Supabase Setup & Migration Guide

This file provides complete installation instructions to set up, authenticate, and secure your SAPC STORE backend using Supabase.

---

## 1. Environment Variable Setup

To connect SAPC STORE with your live Supabase cloud workspace, add the following variables to your `.env` (development) or App Workspace Settings:

```env
# Supabase Configuration
VITE_SUPABASE_URL="https://your-project-id.supabase.co"
VITE_SUPABASE_ANON_KEY="your-supabase-anonymous-public-key"
```

*Note: If these variables are not found or contain placeholder values, the application automatically runs in a secure offline responsive simulator mode using browser state engines (LocalStorage). We highly recommend verifying that these configurations are written safely prior to production launch.*

---

## 2. PostgreSQL Schema Setup

To create the entire backend database structure in your Supabase project:
1. Log in to your [Supabase Dashboard](https://supabase.com).
2. Direct to **SQL Editor** on the left menu.
3. Open a **New Query**.
4. Copy-paste the entire contents of `supabase_schema.sql` located inside the root directory of this project.
5. Click **Run**.

This script establishes the tables described below:
- `users`: Member wallets, upgrade tier level, balance, and VIP expiry times.
- `predictions`: Stored Football AI predictions and game win probability results.
- `matches`: Real-time fixture caches.
- `subscriptions`: Active paid prediction schedules.
- `deposits` and `withdrawals`: Member deposit and payment request ledgers.
- `notifications`: Notifications push logs.
- `video_tasks` and `task_completions`: Rewarded advertising and daily task earnings.
- `activity_logs`: Timed system audit trials.
- `system_settings`: Platform API tokens and mobile paynumbers.

---

## 3. Row Level Security (RLS) Policies

Every single table created in the step above has **Row Level Security (RLS)** active. All access attempts must satisfy specific conditions:

- **users**:
  - Selected profile is limited only to matching authenticated owners (`auth.uid() = uid`).
  - Active admin profiles bypass filters to oversee balance states and roles.
- **predictions** & **subscriptions**:
  - Read/Write privileges restricted specifically to the creator.
- **deposits** & **withdrawals**:
  - Regular users submit items and read own history.
  - Updating status to Approved/Rejected requires an Admin role.
- **system_settings**:
  - Public mobile paynumbers are visible to logged-in members (for payments).
  - Secret OpenAI, Gemini and Football API keys can only be read or written by Administrator roles.

To verify RLS is enabled:
- Go to **Database** -> **Tables** in Supabase and confirm each table has a lock indicator enabled indicating Row-Level Security is active.

---

## 4. Authentication Configuration

SAPC STORE utilizes Supabase Auth for core security. Follow these steps to configure Redirect URLs perfectly and avoid `ERR_CONNECTION_REFUSED` errors on Android:

1. Under **Authentication** -> **Providers** -> **Email**:
   - Ensure the **Enable Email Provider** option is toggled **ON**.
   - Ensure **Confirm Email** can be safely toggled **OFF** if you prefer instantaneous registration paths without initial email verification hoops, or configured appropriately.

2. Under **Authentication** -> **URL Configuration**:
   - **CRITICAL**: Remove all `localhost` redirect URLs (e.g. `http://localhost:3000` or `http://localhost:5173`) from both Site URL and Redirect URLs.
   - **Site URL**: Set this to your live production/preview URL:
     `https://ais-pre-matzexhkokecbdix3cqrzf-449341993460.europe-west2.run.app`
   - **Redirect URLs**: Add the following URLs (one per line):
     - `https://ais-pre-matzexhkokecbdix3cqrzf-449341993460.europe-west2.run.app`
     - `sapcone://auth/callback` *(Crucial for Flutter Android deep linking integration)*

---

## 5. Storage Buckets Creation

If your users need to upload file attachments (such as payment receipts or screenshot references), set up a safe Storage space:
1. Click **Storage** on your Supabase cabinet.
2. Click **Create a New Bucket**.
3. Set the Bucket ID to `receipts` or `receipt-uploads`.
4. Toggle it as a **Public** or **Protected** bucket.
5. Setup RLS policies on the bucket:
   - Allow INSERT if user is logged in.
   - Allow SELECT if user matches uploader or is Admin.

---

## 6. Realtime Events Streams

To authorize instant reactive updates for mobile screens:
1. In your project, go to **Database** -> **Replication**.
2. Select your `supabase_realtime` publication slot.
3. Toggle on **Source Tables** that require real-time updates (e.g., `users`, `deposits`, `withdrawals`, `notifications`).
4. This permits the `.onSnapshot` styled websocket listener inside the client to receive instanstaneous triggers on new approvals or balance increases!
